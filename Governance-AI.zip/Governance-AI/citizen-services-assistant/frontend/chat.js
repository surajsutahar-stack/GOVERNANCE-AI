/**
 * chat.js — Citizen Services Assistant
 * Handles: user interactions, profile collection, API calls, message rendering.
 * No external dependencies — plain vanilla JavaScript.
 */

"use strict";

// ── Constants ─────────────────────────────────────────────────────────────
const API_BASE      = "";          // Same origin as Flask server
const MAX_MSG_LEN   = 500;

// ── State ─────────────────────────────────────────────────────────────────
let sessionId        = null;
let preferredLang    = "en";
let activeCategory   = null;       // Currently selected category filter
let currentSchemeId  = null;       // Scheme currently in focus

// ── DOM references ────────────────────────────────────────────────────────
const messagesEl     = document.getElementById("messages");
const userInputEl    = document.getElementById("user-input");
const chatForm       = document.getElementById("chat-form");
const sendBtn        = document.getElementById("send-btn");
const langSelect     = document.getElementById("lang-select");
const charCount      = document.getElementById("char-count");
const saveProfileBtn = document.getElementById("save-profile-btn");
const profileToggle  = document.getElementById("profile-toggle");
const profileFields  = document.getElementById("profile-fields");
const categoryGrid   = document.getElementById("category-buttons");

// Profile inputs
const ageInput       = document.getElementById("profile-age");
const genderInput    = document.getElementById("profile-gender");
const occupationInput= document.getElementById("profile-occupation");
const incomeInput    = document.getElementById("profile-income");
const stateInput     = document.getElementById("profile-state");
const categoryInput  = document.getElementById("profile-category");

// Error spans
const ageError       = document.getElementById("age-error");
const incomeError    = document.getElementById("income-error");

// ── Initialise ────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  loadCategories();
  showWelcome();
  userInputEl.addEventListener("input", updateCharCount);
  chatForm.addEventListener("submit", handleSubmit);
  langSelect.addEventListener("change", handleLanguageChange);
  saveProfileBtn.addEventListener("click", handleSaveProfile);
  profileToggle.addEventListener("click", toggleProfile);
});

// ── Welcome message ───────────────────────────────────────────────────────
function showWelcome() {
  appendMessage(
    "assistant",
    `👋 **Welcome to the Citizen Services Assistant!**

I can help you:
• Discover government schemes for **farmers, students, women, senior citizens**, and more
• Check if you may be eligible for a scheme
• Understand required documents and how to apply

**To get started:**
1. Select your **preferred language** in the top-right corner
2. Fill in your **profile** on the left for personalised guidance
3. Click a **category** button to browse schemes, or just **type your question** below

⚠️ This assistant provides general guidance only — not official government decisions.`,
    false  // no AI badge on the welcome message
  );
}

// ── Load category buttons ─────────────────────────────────────────────────
async function loadCategories() {
  try {
    const res  = await fetch(`${API_BASE}/schemes/categories`);
    const data = await res.json();
    renderCategoryButtons(data.categories || []);
  } catch {
    categoryGrid.textContent = "(Categories unavailable)";
  }
}

function renderCategoryButtons(categories) {
  categoryGrid.innerHTML = "";
  categories.forEach(cat => {
    const btn = document.createElement("button");
    btn.className  = "btn btn-category";
    btn.textContent = categoryEmoji(cat) + " " + cat;
    btn.dataset.category = cat;
    btn.addEventListener("click", () => handleCategoryClick(cat, btn));
    categoryGrid.appendChild(btn);
  });
}

function categoryEmoji(cat) {
  const map = {
    Agriculture: "🌾", Health: "🏥", Housing: "🏠",
    Education: "📚", Women: "👩", SeniorCitizens: "🧓",
    Employment: "💼", Finance: "💰",
  };
  return map[cat] || "📋";
}

async function handleCategoryClick(category, btn) {
  // Toggle active state
  document.querySelectorAll(".btn-category").forEach(b => b.classList.remove("active"));
  if (activeCategory === category) {
    activeCategory = null;
    return;
  }
  activeCategory = category;
  btn.classList.add("active");

  // Search schemes for this category
  try {
    const res  = await fetch(`${API_BASE}/schemes/search?category=${encodeURIComponent(category)}`);
    const data = await res.json();
    renderSchemeList(data.schemes || [], category);
  } catch {
    appendMessage("assistant", "Sorry, I could not load schemes right now. Please try again.");
  }
}

function renderSchemeList(schemes, category) {
  if (schemes.length === 0) {
    appendMessage("assistant", `No schemes found in the **${category}** category.`);
    return;
  }

  let md = `**${categoryEmoji(category)} ${category} Schemes**\n\nHere are the available schemes:\n\n`;
  schemes.forEach((s, i) => {
    md += `**${i + 1}. ${s.scheme_name}**\n`;
    md += `${s.description_simple}\n`;
    md += `[→ Official Portal](${s.apply_portal_url})\n\n`;
  });
  md += `*Click a scheme name or ask me about any of these for more details!*`;

  appendMessage("assistant", md, true);

  // Store first scheme as current context
  if (schemes.length === 1) {
    currentSchemeId = schemes[0].scheme_id;
  }
}

// ── Language change ───────────────────────────────────────────────────────
function handleLanguageChange() {
  preferredLang = langSelect.value;
  const langNames = { en: "English", hi: "Hindi", mr: "Marathi", gu: "Gujarati", kn: "Kannada" };
  appendMessage(
    "assistant",
    `Language set to **${langNames[preferredLang] || preferredLang}**. ` +
    `I will now respond in this language.`,
    false
  );
}

// ── Profile panel toggle ──────────────────────────────────────────────────
function toggleProfile() {
  const expanded = profileToggle.getAttribute("aria-expanded") === "true";
  profileToggle.setAttribute("aria-expanded", String(!expanded));
  profileFields.hidden = expanded;
}

// ── Save profile ──────────────────────────────────────────────────────────
function handleSaveProfile(e) {
  e.preventDefault();
  if (!validateProfileForm()) return;
  showToast("✅ Profile saved! Fill in more details or start chatting.");
}

function validateProfileForm() {
  let valid = true;

  // Age
  ageError.textContent = "";
  const age = ageInput.value.trim();
  if (age !== "") {
    const ageNum = parseInt(age, 10);
    if (isNaN(ageNum) || ageNum < 0 || ageNum > 120) {
      ageError.textContent = "Age must be between 0 and 120.";
      valid = false;
    }
  }

  // Income
  incomeError.textContent = "";
  const income = incomeInput.value.trim();
  if (income !== "") {
    const incNum = parseInt(income, 10);
    if (isNaN(incNum) || incNum < 0) {
      incomeError.textContent = "Income must be a positive number.";
      valid = false;
    }
  }

  return valid;
}

function getProfile() {
  const profile = {};
  const age = parseInt(ageInput.value, 10);
  if (!isNaN(age)) profile.age = age;
  if (genderInput.value)      profile.gender         = genderInput.value;
  if (occupationInput.value)  profile.occupation     = occupationInput.value.trim();
  const income = parseInt(incomeInput.value, 10);
  if (!isNaN(income))         profile.annual_income_inr = income;
  if (stateInput.value)       profile.state          = stateInput.value;
  if (categoryInput.value)    profile.social_category = categoryInput.value;
  return profile;
}

// ── Chat form submit ──────────────────────────────────────────────────────
async function handleSubmit(e) {
  e.preventDefault();

  const text = userInputEl.value.trim();
  if (!text) {
    userInputEl.focus();
    return;
  }
  if (text.length > MAX_MSG_LEN) {
    showToast("⚠️ Message too long. Max 500 characters.");
    return;
  }

  // Display user message
  appendMessage("user", text);
  userInputEl.value = "";
  updateCharCount();

  // Detect if message references a specific scheme from category browse
  const detectedScheme = detectSchemeId(text);
  if (detectedScheme) currentSchemeId = detectedScheme;

  // Show typing indicator
  const typingId = showTyping();

  // Build request
  const body = {
    message:    text,
    session_id: sessionId,
    language:   preferredLang,
    profile:    getProfile(),
    scheme_id:  currentSchemeId || undefined,
  };

  try {
    const res  = await fetch(`${API_BASE}/chat`, {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify(body),
    });

    const data = await res.json();

    // Update session ID
    if (data.session_id) sessionId = data.session_id;

    // Update current scheme context
    if (data.scheme_context) {
      currentSchemeId = data.scheme_context.scheme_id;
    }

    removeTyping(typingId);

    // Show validation errors as a separate note
    if (data.validation_errors && data.validation_errors.length > 0) {
      const errMsg = "⚠️ Note: " + data.validation_errors.join(" | ");
      appendMessage("assistant", errMsg, false);
    }

    appendMessage("assistant", data.response || "I'm sorry, I could not generate a response.", true);

    // If eligibility result is present, show a summary card
    if (data.eligibility_result) {
      renderEligibilityCard(data.eligibility_result, data.scheme_context);
    }

  } catch (err) {
    removeTyping(typingId);
    appendMessage(
      "assistant",
      "⚠️ I'm sorry — there was a connection problem. Please check your server is running and try again."
    );
  }

  sendBtn.disabled = false;
}

// ── Scheme ID detection (simple keyword match) ────────────────────────────
const SCHEME_KEYWORDS = {
  "pm-kisan":             ["pm kisan", "kisan samman", "pmkisan"],
  "pm-fasal-bima":        ["fasal bima", "pmfby", "crop insurance"],
  "kisan-credit-card":    ["kisan credit", "kcc"],
  "ayushman-bharat":      ["ayushman", "pmjay", "pm-jay", "jan arogya"],
  "pmay-gramin":          ["pmay gramin", "pmayg", "rural housing"],
  "pmay-urban":           ["pmay urban", "pmay-u", "urban housing"],
  "national-scholarship": ["national scholarship", "nsp scholarship"],
  "pm-scholarship-ex-servicemen": ["pm scholarship", "ex-servicemen scholarship"],
  "beti-bachao":          ["beti bachao", "bbbp", "sukanya"],
  "pm-ujjwala":           ["ujjwala", "lpg connection", "cooking gas"],
  "ignoaps":              ["ignoaps", "old age pension", "indira gandhi pension"],
  "mgnregs":              ["mgnregs", "mgnrega", "nrega", "100 days"],
  "pm-mudra":             ["mudra", "pmmy", "mudra loan"],
  "skill-india-pmkvy":    ["pmkvy", "skill india", "kaushal vikas"],
  "pm-jan-dhan":          ["jan dhan", "pmjdy", "zero balance account"],
};

function detectSchemeId(text) {
  const lower = text.toLowerCase();
  for (const [id, keywords] of Object.entries(SCHEME_KEYWORDS)) {
    if (keywords.some(kw => lower.includes(kw))) return id;
  }
  return null;
}

// ── Eligibility card ──────────────────────────────────────────────────────
function renderEligibilityCard(result, schemeCtx) {
  const statusIcon = {
    likely_eligible:   "✅",
    may_not_qualify:   "❌",
    insufficient_data: "ℹ️",
  }[result.match_status] || "ℹ️";

  let html = `<div class="scheme-card">`;
  html += `<strong>${statusIcon} Eligibility Check: ${escapeHtml(result.scheme_name)}</strong><br/>`;
  html += `<em>${escapeHtml(result.summary)}</em>`;

  if (result.rules_checked && result.rules_checked.length > 0) {
    html += `<ul style="margin-top:0.5rem">`;
    result.rules_checked.forEach(r => {
      const icon = r.passed ? "✅" : "❌";
      html += `<li>${icon} <strong>${escapeHtml(r.rule)}</strong>: `;
      html += `${escapeHtml(r.user_value)} (needed: ${escapeHtml(r.required)})`;
      if (r.note) html += ` — <em>${escapeHtml(r.note)}</em>`;
      html += `</li>`;
    });
    html += `</ul>`;
  }

  if (result.missing_fields && result.missing_fields.length > 0) {
    html += `<p style="margin-top:0.4rem;font-size:0.8rem;color:#666">`;
    html += `Missing info: ${result.missing_fields.join(", ")} — `;
    html += `fill your profile for a more complete check.</p>`;
  }

  if (schemeCtx && schemeCtx.apply_portal_url) {
    html += `<a href="${escapeHtml(schemeCtx.apply_portal_url)}" target="_blank" rel="noopener">`;
    html += `→ Apply on official portal</a>`;
  }

  html += `</div>`;

  // Append the card into the last assistant bubble
  const bubbles = messagesEl.querySelectorAll(".message.assistant .bubble");
  const last = bubbles[bubbles.length - 1];
  if (last) {
    last.insertAdjacentHTML("beforeend", html);
  } else {
    const div = createMessageElement("assistant", "", true);
    div.querySelector(".bubble").innerHTML = html;
    messagesEl.appendChild(div);
  }
  scrollToBottom();
}

// ── Message rendering ─────────────────────────────────────────────────────
function appendMessage(role, text, showBadge = false) {
  const el = createMessageElement(role, text, showBadge);
  messagesEl.appendChild(el);
  scrollToBottom();
  return el;
}

function createMessageElement(role, text, showBadge) {
  const wrapper  = document.createElement("div");
  wrapper.className = `message ${role}`;

  if (showBadge && role === "assistant") {
    const badge = document.createElement("div");
    badge.className   = "ai-badge";
    badge.textContent = "🤖 AI Guidance — Not an official government decision";
    wrapper.appendChild(badge);
  }

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  bubble.innerHTML  = markdownToHtml(text);
  wrapper.appendChild(bubble);
  return wrapper;
}

// ── Typing indicator ──────────────────────────────────────────────────────
function showTyping() {
  const wrapper  = document.createElement("div");
  wrapper.className = "message assistant";
  wrapper.id        = "typing-" + Date.now();

  const bubble = document.createElement("div");
  bubble.className = "bubble";
  const ind = document.createElement("div");
  ind.className = "typing-indicator";
  ind.innerHTML = "<span></span><span></span><span></span>";
  bubble.appendChild(ind);
  wrapper.appendChild(bubble);
  messagesEl.appendChild(wrapper);
  scrollToBottom();
  sendBtn.disabled = true;
  return wrapper.id;
}

function removeTyping(id) {
  const el = document.getElementById(id);
  if (el) el.remove();
}

// ── Utility ───────────────────────────────────────────────────────────────
function scrollToBottom() {
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function updateCharCount() {
  const len = userInputEl.value.length;
  charCount.textContent = `${len} / ${MAX_MSG_LEN}`;
  charCount.style.color = len > MAX_MSG_LEN * 0.9 ? "#c0392b" : "#8a96a3";
}

function showToast(msg) {
  let toast = document.querySelector(".toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.className = "toast";
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 3000);
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

/**
 * Minimal Markdown-to-HTML converter.
 * Supports: **bold**, *italic*, `code`, [text](url), bullet lists, numbered lists,
 * headers (##), horizontal rules (---), line breaks.
 */
function markdownToHtml(text) {
  if (!text) return "";
  let html = escapeHtml(text);

  // Headers
  html = html.replace(/^### (.+)$/gm, "<h4>$1</h4>");
  html = html.replace(/^## (.+)$/gm,  "<h3>$1</h3>");
  html = html.replace(/^# (.+)$/gm,   "<h2>$1</h2>");

  // Horizontal rule
  html = html.replace(/^---+$/gm, "<hr/>");

  // Bold and italic (must come before single *)
  html = html.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/\*(.+?)\*/g,     "<em>$1</em>");

  // Inline code
  html = html.replace(/`([^`]+)`/g, "<code>$1</code>");

  // Links
  html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g,
    '<a href="$2" target="_blank" rel="noopener">$1</a>');

  // Bullet lists
  html = html.replace(/((?:^• .+\n?)+)/gm, (match) => {
    const items = match.trim().split(/\n/).map(l =>
      `<li>${l.replace(/^• /, "")}</li>`).join("");
    return `<ul>${items}</ul>`;
  });

  // Numbered lists
  html = html.replace(/((?:^\d+\. .+\n?)+)/gm, (match) => {
    const items = match.trim().split(/\n/).map(l =>
      `<li>${l.replace(/^\d+\. /, "")}</li>`).join("");
    return `<ol>${items}</ol>`;
  });

  // Newlines to <br>
  html = html.replace(/\n/g, "<br/>");

  return html;
}
