# conftest.py — pytest configuration for citizen-services-assistant tests
# Adds the project root to sys.path so tests can import backend modules.
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))
