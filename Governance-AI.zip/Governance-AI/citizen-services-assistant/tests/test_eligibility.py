"""
test_eligibility.py
Unit tests for backend/eligibility.py (EligibilityChecker) and
backend/disclaimer.py (DisclaimerInjector).

Run with:  pytest tests/test_eligibility.py -v
"""

import sys
import os

# Allow imports from the backend package
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from backend.eligibility import EligibilityChecker, EligibilityResult, RuleCheck
from backend.disclaimer import DisclaimerInjector, DISCLAIMER_TEXTS


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

CHECKER = EligibilityChecker()

# --- Minimal scheme records used in tests ---

SCHEME_PM_KISAN = {
    "scheme_id": "pm-kisan",
    "scheme_name": "PM Kisan Samman Nidhi",
    "eligibility_rules": {
        "min_age": 18,
        "max_age": None,
        "gender": "Any",
        "occupation": ["Farmer", "Agricultural Laborer", "Cultivator"],
        "income_max_annual_inr": None,
        "social_category": ["ANY"],
        "state_required": "ALL",
        "other_conditions": "Must own cultivable land.",
    },
}

SCHEME_IGNOAPS = {
    "scheme_id": "ignoaps",
    "scheme_name": "IGNOAPS Old Age Pension",
    "eligibility_rules": {
        "min_age": 60,
        "max_age": None,
        "gender": "Any",
        "occupation": ["ANY"],
        "income_max_annual_inr": None,
        "social_category": ["ANY"],
        "state_required": "ALL",
        "other_conditions": "Must be BPL household.",
    },
}

SCHEME_PMAY_GRAMIN = {
    "scheme_id": "pmay-gramin",
    "scheme_name": "PMAY Gramin",
    "eligibility_rules": {
        "min_age": 18,
        "max_age": None,
        "gender": "Any",
        "occupation": ["ANY"],
        "income_max_annual_inr": 200000,
        "social_category": ["ANY"],
        "state_required": "ALL",
        "other_conditions": "Must be rural resident without pucca house.",
    },
}

SCHEME_BETI_BACHAO = {
    "scheme_id": "beti-bachao",
    "scheme_name": "Beti Bachao Beti Padhao",
    "eligibility_rules": {
        "min_age": None,
        "max_age": 10,
        "gender": "Female",
        "occupation": ["ANY"],
        "income_max_annual_inr": None,
        "social_category": ["ANY"],
        "state_required": "ALL",
        "other_conditions": "Sukanya Samriddhi Account for girl child up to 10 years.",
    },
}

SCHEME_STATE_RESTRICTED = {
    "scheme_id": "state-scheme",
    "scheme_name": "Demo State Scheme",
    "eligibility_rules": {
        "min_age": 18,
        "max_age": None,
        "gender": "Any",
        "occupation": ["ANY"],
        "income_max_annual_inr": None,
        "social_category": ["SC", "ST"],
        "state_required": "Maharashtra",
        "other_conditions": "",
    },
}

SCHEME_KCC = {
    "scheme_id": "kisan-credit-card",
    "scheme_name": "Kisan Credit Card",
    "eligibility_rules": {
        "min_age": 18,
        "max_age": 75,
        "gender": "Any",
        "occupation": ["Farmer", "Cultivator", "Fisherman", "Animal Husbandry farmer"],
        "income_max_annual_inr": None,
        "social_category": ["ANY"],
        "state_required": "ALL",
        "other_conditions": "",
    },
}


# ---------------------------------------------------------------------------
# Tests: likely_eligible cases
# ---------------------------------------------------------------------------

class TestLikelyEligible:
    def test_farmer_pm_kisan_all_rules_pass(self) -> None:
        profile = {
            "age": 35,
            "gender": "Male",
            "occupation": "Farmer",
            "annual_income_inr": 100000,
            "state": "Maharashtra",
            "social_category": "General",
        }
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        assert result.match_status == "likely_eligible"
        assert result.scheme_id == "pm-kisan"

    def test_elderly_citizen_ignoaps_eligible(self) -> None:
        profile = {
            "age": 65,
            "gender": "Female",
            "occupation": "None",
            "annual_income_inr": 50000,
            "state": "Bihar",
            "social_category": "SC",
        }
        result = CHECKER.check(profile, SCHEME_IGNOAPS)
        assert result.match_status == "likely_eligible"

    def test_income_exactly_at_maximum_is_eligible(self) -> None:
        profile = {
            "age": 30,
            "annual_income_inr": 200000,   # exactly at limit
            "state": "UP",
            "social_category": "OBC",
        }
        result = CHECKER.check(profile, SCHEME_PMAY_GRAMIN)
        assert result.match_status == "likely_eligible"

    def test_girl_child_beti_bachao(self) -> None:
        profile = {
            "age": 5,
            "gender": "Female",
            "social_category": "General",
        }
        result = CHECKER.check(profile, SCHEME_BETI_BACHAO)
        assert result.match_status == "likely_eligible"

    def test_fisherman_kisan_credit_card(self) -> None:
        profile = {
            "age": 40,
            "occupation": "Fisherman",
        }
        result = CHECKER.check(profile, SCHEME_KCC)
        assert result.match_status == "likely_eligible"


# ---------------------------------------------------------------------------
# Tests: may_not_qualify cases
# ---------------------------------------------------------------------------

class TestMayNotQualify:
    def test_too_young_for_pm_kisan(self) -> None:
        profile = {
            "age": 15,
            "occupation": "Farmer",
        }
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        assert result.match_status == "may_not_qualify"
        age_check = next(c for c in result.rules_checked if c.rule == "Age")
        assert not age_check.passed

    def test_teacher_not_eligible_for_pm_kisan(self) -> None:
        profile = {
            "age": 35,
            "occupation": "Teacher",
        }
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        assert result.match_status == "may_not_qualify"
        occ_check = next(c for c in result.rules_checked if c.rule == "Occupation")
        assert not occ_check.passed

    def test_income_too_high_for_pmay(self) -> None:
        profile = {
            "age": 28,
            "annual_income_inr": 500000,
        }
        result = CHECKER.check(profile, SCHEME_PMAY_GRAMIN)
        assert result.match_status == "may_not_qualify"
        income_check = next(c for c in result.rules_checked if c.rule == "Annual Income")
        assert not income_check.passed

    def test_too_young_for_ignoaps(self) -> None:
        profile = {
            "age": 45,
        }
        result = CHECKER.check(profile, SCHEME_IGNOAPS)
        assert result.match_status == "may_not_qualify"

    def test_boy_not_eligible_for_beti_bachao(self) -> None:
        profile = {
            "age": 5,
            "gender": "Male",
        }
        result = CHECKER.check(profile, SCHEME_BETI_BACHAO)
        assert result.match_status == "may_not_qualify"
        gender_check = next(c for c in result.rules_checked if c.rule == "Gender")
        assert not gender_check.passed

    def test_wrong_state_for_state_scheme(self) -> None:
        profile = {
            "age": 25,
            "state": "Gujarat",
            "social_category": "SC",
        }
        result = CHECKER.check(profile, SCHEME_STATE_RESTRICTED)
        assert result.match_status == "may_not_qualify"
        state_check = next(c for c in result.rules_checked if c.rule == "State")
        assert not state_check.passed

    def test_wrong_social_category_for_state_scheme(self) -> None:
        profile = {
            "age": 25,
            "state": "Maharashtra",
            "social_category": "General",
        }
        result = CHECKER.check(profile, SCHEME_STATE_RESTRICTED)
        assert result.match_status == "may_not_qualify"
        cat_check = next(c for c in result.rules_checked if c.rule == "Social Category")
        assert not cat_check.passed

    def test_over_max_age_for_kcc(self) -> None:
        profile = {
            "age": 80,
            "occupation": "Farmer",
        }
        result = CHECKER.check(profile, SCHEME_KCC)
        assert result.match_status == "may_not_qualify"

    def test_failed_check_recorded_in_rules_checked(self) -> None:
        profile = {"age": 15, "occupation": "Farmer"}
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        failed = [c for c in result.rules_checked if not c.passed]
        assert len(failed) >= 1
        assert any(c.rule == "Age" for c in failed)


# ---------------------------------------------------------------------------
# Tests: insufficient_data cases
# ---------------------------------------------------------------------------

class TestInsufficientData:
    def test_empty_profile_returns_insufficient_data(self) -> None:
        result = CHECKER.check({}, SCHEME_PM_KISAN)
        assert result.match_status == "insufficient_data"
        assert len(result.missing_fields) > 0

    def test_missing_age_listed_in_missing_fields(self) -> None:
        profile = {"occupation": "Farmer"}
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        assert "age" in result.missing_fields

    def test_missing_income_listed_for_income_restricted_scheme(self) -> None:
        profile = {"age": 25, "state": "UP"}
        result = CHECKER.check(profile, SCHEME_PMAY_GRAMIN)
        assert "annual_income_inr" in result.missing_fields

    def test_result_has_scheme_id(self) -> None:
        result = CHECKER.check({}, SCHEME_PM_KISAN)
        assert result.scheme_id == "pm-kisan"
        assert result.scheme_name == "PM Kisan Samman Nidhi"

    def test_summary_mentions_missing_fields(self) -> None:
        profile = {}
        result = CHECKER.check(profile, SCHEME_PMAY_GRAMIN)
        assert result.match_status == "insufficient_data"
        assert len(result.summary) > 0


# ---------------------------------------------------------------------------
# Tests: Occupation partial matching
# ---------------------------------------------------------------------------

class TestOccupationMatching:
    def test_cultivator_matches_farmer_scheme(self) -> None:
        profile = {"age": 30, "occupation": "Cultivator"}
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        occ_check = next((c for c in result.rules_checked if c.rule == "Occupation"), None)
        assert occ_check is not None
        assert occ_check.passed

    def test_small_farmer_partial_match(self) -> None:
        profile = {"age": 30, "occupation": "Small farmer"}
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        occ_check = next((c for c in result.rules_checked if c.rule == "Occupation"), None)
        assert occ_check is not None
        assert occ_check.passed

    def test_engineer_does_not_match_farmer(self) -> None:
        profile = {"age": 30, "occupation": "Engineer"}
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        occ_check = next((c for c in result.rules_checked if c.rule == "Occupation"), None)
        assert occ_check is not None
        assert not occ_check.passed


# ---------------------------------------------------------------------------
# Tests: EligibilityResult structure
# ---------------------------------------------------------------------------

class TestResultStructure:
    def test_result_is_eligibility_result_type(self) -> None:
        result = CHECKER.check({"age": 35, "occupation": "Farmer"}, SCHEME_PM_KISAN)
        assert isinstance(result, EligibilityResult)

    def test_rules_checked_are_rule_check_instances(self) -> None:
        result = CHECKER.check({"age": 35, "occupation": "Farmer"}, SCHEME_PM_KISAN)
        for check in result.rules_checked:
            assert isinstance(check, RuleCheck)

    def test_summary_is_non_empty_string(self) -> None:
        result = CHECKER.check({"age": 35, "occupation": "Farmer"}, SCHEME_PM_KISAN)
        assert isinstance(result.summary, str)
        assert len(result.summary.strip()) > 0


# ---------------------------------------------------------------------------
# Tests: DisclaimerInjector
# ---------------------------------------------------------------------------

class TestDisclaimerInjector:
    INJECTOR = DisclaimerInjector()

    def test_eligibility_text_needs_disclaimer(self) -> None:
        text = "You may be eligible for PM-KISAN based on your profile."
        assert self.INJECTOR.needs_disclaimer(text) is True

    def test_general_question_does_not_need_disclaimer(self) -> None:
        text = "PM-KISAN provides ₹6,000 per year to farming families."
        assert self.INJECTOR.needs_disclaimer(text) is False

    def test_inject_appends_english_disclaimer(self) -> None:
        text = "You may be eligible for this scheme."
        result = self.INJECTOR.inject(text, "en")
        assert "DISCLAIMER" in result
        assert "official government portal" in result

    def test_inject_appends_hindi_disclaimer(self) -> None:
        text = "आप इस योजना के लिए पात्र हो सकते हैं।"
        result = self.INJECTOR.inject(text, "hi")
        assert "महत्वपूर्ण सूचना" in result

    def test_inject_appends_marathi_disclaimer(self) -> None:
        text = "You are likely eligible."
        result = self.INJECTOR.inject(text, "mr")
        assert "महत्त्वाची सूचना" in result

    def test_inject_appends_gujarati_disclaimer(self) -> None:
        text = "You may qualify for this benefit."
        result = self.INJECTOR.inject(text, "gu")
        assert "મહત્વની નોંધ" in result

    def test_inject_appends_kannada_disclaimer(self) -> None:
        text = "You are eligible."
        result = self.INJECTOR.inject(text, "kn")
        assert "ಮುಖ್ಯ ಸೂಚನೆ" in result

    def test_no_double_disclaimer(self) -> None:
        text = "You may be eligible. DISCLAIMER: This is guidance only."
        result = self.INJECTOR.inject(text, "en")
        # Should not add a second disclaimer
        assert result.count("DISCLAIMER") == 1

    def test_unsupported_language_falls_back_to_english(self) -> None:
        text = "You may qualify for this."
        result = self.INJECTOR.inject(text, "xx")
        assert "DISCLAIMER" in result

    def test_non_eligibility_text_unchanged(self) -> None:
        text = "Here are the documents you need: Aadhaar card, bank passbook."
        result = self.INJECTOR.inject(text, "en")
        assert result == text

    def test_all_language_disclaimers_are_present(self) -> None:
        for lang in ("en", "hi", "mr", "gu", "kn"):
            assert lang in DISCLAIMER_TEXTS
            assert len(DISCLAIMER_TEXTS[lang]) > 50


# ---------------------------------------------------------------------------
# Tests: Input validation edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_age_exactly_at_minimum(self) -> None:
        profile = {"age": 18, "occupation": "Farmer"}
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        age_check = next((c for c in result.rules_checked if c.rule == "Age"), None)
        assert age_check is not None
        assert age_check.passed

    def test_age_one_below_minimum_fails(self) -> None:
        profile = {"age": 17, "occupation": "Farmer"}
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        age_check = next((c for c in result.rules_checked if c.rule == "Age"), None)
        assert age_check is not None
        assert not age_check.passed

    def test_income_one_above_max_fails(self) -> None:
        profile = {"age": 25, "annual_income_inr": 200001}
        result = CHECKER.check(profile, SCHEME_PMAY_GRAMIN)
        income_check = next((c for c in result.rules_checked if c.rule == "Annual Income"), None)
        assert income_check is not None
        assert not income_check.passed

    def test_zero_income_passes_income_check(self) -> None:
        profile = {"age": 25, "annual_income_inr": 0}
        result = CHECKER.check(profile, SCHEME_PMAY_GRAMIN)
        income_check = next((c for c in result.rules_checked if c.rule == "Annual Income"), None)
        assert income_check is not None
        assert income_check.passed

    def test_scheme_without_income_rule_no_income_check(self) -> None:
        # PM-KISAN has no income restriction
        profile = {"age": 35, "occupation": "Farmer", "annual_income_inr": 9999999}
        result = CHECKER.check(profile, SCHEME_PM_KISAN)
        income_checks = [c for c in result.rules_checked if c.rule == "Annual Income"]
        assert len(income_checks) == 0

    def test_case_insensitive_social_category(self) -> None:
        profile = {
            "age": 25,
            "state": "Maharashtra",
            "social_category": "sc",  # lowercase
        }
        result = CHECKER.check(profile, SCHEME_STATE_RESTRICTED)
        cat_check = next((c for c in result.rules_checked if c.rule == "Social Category"), None)
        assert cat_check is not None
        assert cat_check.passed
