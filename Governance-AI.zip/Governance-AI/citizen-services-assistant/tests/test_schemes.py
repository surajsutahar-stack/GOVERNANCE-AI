"""
test_schemes.py
Validates that data/schemes.json is well-formed and every scheme record
matches the expected data model. Run with:  pytest tests/test_schemes.py -v
"""
import json
import os
import re
import pytest
from typing import Any

# ---------------------------------------------------------------------------
# Load data once for the entire test session
# ---------------------------------------------------------------------------
DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "schemes.json")

with open(DATA_PATH, encoding="utf-8") as f:
    _RAW = json.load(f)

SCHEMES: list[dict[str, Any]] = _RAW["schemes"]

REQUIRED_SCHEME_FIELDS = [
    "scheme_id",
    "scheme_name",
    "department",
    "category",
    "applicable_states",
    "description_simple",
    "description_official",
    "eligibility_rules",
    "required_documents",
    "how_to_apply",
    "apply_portal_url",
    "source_url",
    "last_verified_date",
]

REQUIRED_ELIGIBILITY_FIELDS = [
    "min_age",
    "max_age",
    "gender",
    "occupation",
    "income_max_annual_inr",
    "social_category",
    "state_required",
    "other_conditions",
]

ALLOWED_CATEGORIES = {
    "Agriculture",
    "Health",
    "Housing",
    "Education",
    "Women",
    "SeniorCitizens",
    "Employment",
    "Finance",
}

URL_PATTERN = re.compile(r"^https?://")


# ---------------------------------------------------------------------------
# Top-level file structure
# ---------------------------------------------------------------------------

class TestFileStructure:
    def test_top_level_keys_present(self) -> None:
        assert "_metadata" in _RAW
        assert "schemes" in _RAW

    def test_schemes_is_list(self) -> None:
        assert isinstance(SCHEMES, list)

    def test_scheme_count_matches_metadata(self) -> None:
        expected = _RAW["_metadata"]["total_schemes"]
        assert len(SCHEMES) == expected, (
            f"Metadata says {expected} schemes but found {len(SCHEMES)}"
        )

    def test_minimum_scheme_count(self) -> None:
        assert len(SCHEMES) >= 10, "Dataset must have at least 10 scheme records"


# ---------------------------------------------------------------------------
# Per-scheme field presence and types
# ---------------------------------------------------------------------------

class TestSchemeFields:
    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_required_fields_present(self, scheme: dict) -> None:
        for field in REQUIRED_SCHEME_FIELDS:
            assert field in scheme, f"Scheme '{scheme.get('scheme_id')}' missing field '{field}'"

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_scheme_id_is_non_empty_string(self, scheme: dict) -> None:
        assert isinstance(scheme["scheme_id"], str)
        assert len(scheme["scheme_id"].strip()) > 0

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_scheme_name_is_non_empty_string(self, scheme: dict) -> None:
        assert isinstance(scheme["scheme_name"], str)
        assert len(scheme["scheme_name"].strip()) > 0

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_category_is_allowed_value(self, scheme: dict) -> None:
        assert scheme["category"] in ALLOWED_CATEGORIES, (
            f"Scheme '{scheme['scheme_id']}' has unknown category '{scheme['category']}'"
        )

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_applicable_states_is_list(self, scheme: dict) -> None:
        assert isinstance(scheme["applicable_states"], list)
        assert len(scheme["applicable_states"]) > 0

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_required_documents_is_non_empty_list(self, scheme: dict) -> None:
        docs = scheme["required_documents"]
        assert isinstance(docs, list)
        assert len(docs) > 0, f"Scheme '{scheme['scheme_id']}' has no required documents"

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_apply_portal_url_format(self, scheme: dict) -> None:
        url = scheme["apply_portal_url"]
        assert isinstance(url, str)
        assert URL_PATTERN.match(url), f"Invalid URL in '{scheme['scheme_id']}': {url}"

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_description_simple_not_empty(self, scheme: dict) -> None:
        desc = scheme["description_simple"]
        assert isinstance(desc, str) and len(desc.strip()) > 0


# ---------------------------------------------------------------------------
# Eligibility rules sub-model
# ---------------------------------------------------------------------------

class TestEligibilityRules:
    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_eligibility_rules_present_and_is_dict(self, scheme: dict) -> None:
        rules = scheme["eligibility_rules"]
        assert isinstance(rules, dict)

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_eligibility_required_fields(self, scheme: dict) -> None:
        rules = scheme["eligibility_rules"]
        for field in REQUIRED_ELIGIBILITY_FIELDS:
            assert field in rules, (
                f"Scheme '{scheme['scheme_id']}' eligibility_rules missing '{field}'"
            )

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_age_fields_are_int_or_null(self, scheme: dict) -> None:
        rules = scheme["eligibility_rules"]
        for age_field in ("min_age", "max_age"):
            val = rules[age_field]
            assert val is None or isinstance(val, int), (
                f"Scheme '{scheme['scheme_id']}' {age_field} must be int or null"
            )

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_age_range_is_logical(self, scheme: dict) -> None:
        rules = scheme["eligibility_rules"]
        min_a = rules["min_age"]
        max_a = rules["max_age"]
        if min_a is not None and max_a is not None:
            assert min_a <= max_a, (
                f"Scheme '{scheme['scheme_id']}' min_age ({min_a}) > max_age ({max_a})"
            )

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_occupation_is_list(self, scheme: dict) -> None:
        occ = scheme["eligibility_rules"]["occupation"]
        assert isinstance(occ, list) and len(occ) > 0

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_social_category_is_list(self, scheme: dict) -> None:
        cat = scheme["eligibility_rules"]["social_category"]
        assert isinstance(cat, list) and len(cat) > 0

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_income_is_int_or_null(self, scheme: dict) -> None:
        income = scheme["eligibility_rules"]["income_max_annual_inr"]
        assert income is None or isinstance(income, int), (
            f"Scheme '{scheme['scheme_id']}' income_max_annual_inr must be int or null"
        )

    @pytest.mark.parametrize("scheme", SCHEMES, ids=[s["scheme_id"] for s in SCHEMES])
    def test_income_is_non_negative(self, scheme: dict) -> None:
        income = scheme["eligibility_rules"]["income_max_annual_inr"]
        if income is not None:
            assert income >= 0, (
                f"Scheme '{scheme['scheme_id']}' has negative income_max_annual_inr"
            )


# ---------------------------------------------------------------------------
# Uniqueness checks
# ---------------------------------------------------------------------------

class TestUniqueness:
    def test_no_duplicate_scheme_ids(self) -> None:
        ids = [s["scheme_id"] for s in SCHEMES]
        assert len(ids) == len(set(ids)), "Duplicate scheme_id values found in schemes.json"

    def test_no_duplicate_scheme_names(self) -> None:
        names = [s["scheme_name"] for s in SCHEMES]
        assert len(names) == len(set(names)), "Duplicate scheme_name values found in schemes.json"
