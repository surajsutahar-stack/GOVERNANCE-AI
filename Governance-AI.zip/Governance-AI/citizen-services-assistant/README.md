# 🏛️ Citizen Services Assistant

An **IBM Bob-powered** AI assistant that helps Indian citizens discover government
schemes, check basic eligibility, understand required documents, and learn how to apply
— all through a simple chat interface available in **English, Hindi, Marathi, Gujarati,
and Kannada**.

> ⚠️ **DISCLAIMER:** This is a demonstration project for educational purposes.
> It provides AI-generated guidance only. It is **not** an official government service
> and does **not** guarantee eligibility or benefit approval.
> Always verify through official government portals.

---

## 📁 Project Structure

```
citizen-services-assistant/
│
├── .bob/                          # IBM Bob configuration
│   ├── custom_modes.yaml          # Defines the "citizen-guide" Bob mode
│   ├── rules/
│   │   └── citizen-guide-rules.md # Always-on guardrails (disclaimer, no hallucination)
│   ├── skills/
│   │   └── scheme-guide.md        # Domain knowledge skill loaded on demand
│   └── mcp/
│       └── mcp.json               # Registers the local MCP server with Bob
│
├── data/
│   └── schemes.json               # All 15 government scheme records (single source of truth)
│
├── backend/
│   ├── app.py                     # Flask server — main entry point
│   ├── eligibility.py             # Deterministic rule-based eligibility checker
│   ├── disclaimer.py              # Legal disclaimer injector (second safety net)
│   ├── session.py                 # In-memory session manager (no disk writes)
│   ├── validation.py              # Input validation for all user fields
│   ├── scheme_store.py            # Reads and searches schemes.json
│   ├── ai_assistant.py            # IBM watsonx.ai API wrapper (with demo mode)
│   └── mcp_server.py              # Local MCP server exposing scheme data to Bob
│
├── frontend/
│   ├── index.html                 # Chat page
│   ├── style.css                  # Accessible, mobile-friendly styles
│   └── chat.js                    # Handles messages, API calls, profile, languages
│
├── tests/
│   ├── test_eligibility.py        # Unit tests for eligibility checker + disclaimer
│   └── test_schemes.py            # Data validation tests for schemes.json
│
├── conftest.py                    # pytest path configuration
├── requirements.txt               # Python dependencies
└── README.md                      # This file
```

---

## 🚀 Quick Start

### 1. Requirements

- Python 3.11 or higher
- A modern web browser (Chrome, Firefox, Edge)

> **Windows note:** If `python` or `pip` are not recognised in PowerShell, use the full
> Python executable path instead (see the commands below). To fix this permanently, add
> `C:\Users\suraj\AppData\Local\Python\pythoncore-3.14-64\` and its `Scripts\` subfolder
> to your Windows PATH (Settings → System → Advanced system settings → Environment Variables
> → Path → New).

### 2. Install dependencies

```powershell
# If 'pip' is not recognised, use the full path:
& "C:\Users\suraj\AppData\Local\Python\pythoncore-3.14-64\python.exe" -m pip install -r requirements.txt

# Once Python is on your PATH you can use the shorter form:
# python -m pip install -r requirements.txt
```

### 3. Run the application

```powershell
# Full path (always works):
& "C:\Users\suraj\AppData\Local\Python\pythoncore-3.14-64\python.exe" backend/app.py

# Short form once Python is on PATH:
# python backend/app.py
```

Open your browser and go to: **http://127.0.0.1:5000**

### 4. (Optional) Configure IBM watsonx.ai for real AI responses

Without API credentials, the app runs in **Demo Mode** — it provides helpful structured
responses using the scheme data, without calling the AI API.

To enable real IBM watsonx.ai AI responses:

```bash
# Set these environment variables before running
set WATSONX_API_KEY=your_api_key_here
set WATSONX_PROJECT_ID=your_project_id_here
set WATSONX_URL=https://us-south.ml.cloud.ibm.com
set WATSONX_MODEL_ID=ibm/granite-3-8b-instruct

python backend/app.py
```

Get your IBM watsonx.ai credentials at: https://dataplatform.cloud.ibm.com

---

## 🧪 Running Tests

```bash
cd citizen-services-assistant
pytest tests/ -v
```

Expected output:
```
tests/test_schemes.py::TestFileStructure::test_top_level_keys_present     PASSED
tests/test_schemes.py::TestFileStructure::test_schemes_is_list             PASSED
... (many more scheme validation tests)
tests/test_eligibility.py::TestLikelyEligible::test_farmer_pm_kisan...    PASSED
tests/test_eligibility.py::TestMayNotQualify::test_too_young_for_pm_kisan  PASSED
... (many more eligibility + disclaimer tests)
```

To run a specific test file:
```bash
pytest tests/test_eligibility.py -v     # Eligibility logic + disclaimer tests
pytest tests/test_schemes.py -v         # Scheme data validation tests
```

---

## 📋 How to Add a New Government Scheme

You **do not need to change any code** to add a new scheme.
Simply open `data/schemes.json` and add a new object to the `"schemes"` array.

**Required fields for each scheme:**

```json
{
  "scheme_id": "unique-slug",
  "scheme_name": "Official Scheme Name",
  "department": "Ministry Name",
  "category": "Agriculture",
  "applicable_states": ["ALL"],
  "description_simple": "Plain-language 2-3 sentence summary.",
  "description_official": "Official description text.",
  "eligibility_rules": {
    "min_age": 18,
    "max_age": null,
    "gender": "Any",
    "occupation": ["Farmer", "ANY"],
    "income_max_annual_inr": null,
    "social_category": ["ANY"],
    "state_required": "ALL",
    "other_conditions": "Any extra conditions in plain text."
  },
  "required_documents": ["Aadhaar card", "Bank passbook"],
  "how_to_apply": "Step-by-step plain text instructions.",
  "apply_portal_url": "https://official-portal.gov.in",
  "source_url": "https://official-source.gov.in",
  "last_verified_date": "2024-12-01"
}
```

**Notes:**
- `scheme_id` must be unique (lowercase, hyphens only)
- `category` must be one of: `Agriculture`, `Health`, `Housing`, `Education`,
  `Women`, `SeniorCitizens`, `Employment`, `Finance`
- Use `"ANY"` in lists (occupation, social_category) to mean "no restriction"
- Use `"ALL"` in `applicable_states` for central schemes
- Use `null` for age/income fields that have no restriction
- After adding, run `pytest tests/test_schemes.py -v` to validate your entry

Also update `_metadata.total_schemes` to the new count.

---

## 🤖 How IBM Bob is Used

This project uses IBM Bob as an **AI development and runtime assistant** in two ways:

### 1. Development time — Bob as your coding assistant

When you open this project in IBM Bob IDE:
- **Bob reads the `AGENTS.md` files** generated by `/init` to understand the project
- **Custom mode `citizen-guide`** (`.bob/custom_modes.yaml`) gives Bob the Citizen
  Services Guide persona — restricting it to scheme-related topics
- **Rules** (`.bob/rules/citizen-guide-rules.md`) are always-on guardrails — Bob will
  always include disclaimers and never invent scheme data
- **Skill** (`.bob/skills/scheme-guide.md`) is loaded on demand to give Bob deep
  knowledge of scheme categories, eligibility patterns, and document types
- **MCP server** (registered in `.bob/mcp/mcp.json`) lets Bob call `search_schemes`,
  `get_scheme_details`, and `list_categories` to fetch real data instead of guessing

### 2. Runtime — Bob's LLM for natural language responses

The `backend/ai_assistant.py` module calls **IBM watsonx.ai** (the LLM powering Bob)
to generate:
- Plain-language explanations of eligibility results
- Multilingual responses in the citizen's chosen language
- Conversational answers to free-text scheme questions
- Follow-up context across a conversation

**Key design decision:** The LLM **explains** eligibility results — it does not
**determine** them. Eligibility is computed by `eligibility.py` (deterministic Python
code). The LLM only narrates the result in human language.

---

## 🌐 Supported Languages

| Language | Code | Method |
|---|---|---|
| English | `en` | Default |
| Hindi | `hi` | LLM translation at query time |
| Marathi | `mr` | LLM translation at query time |
| Gujarati | `gu` | LLM translation at query time |
| Kannada | `kn` | LLM translation at query time |

---

## 🛡️ Responsible AI Features

| Feature | Implementation |
|---|---|
| No eligibility guarantees | Bob rules + disclaimer.py (two independent guardrails) |
| No hallucinated schemes | Bob fetches real data via MCP — cannot invent schemes |
| Legal disclaimer | Appended to every eligibility response automatically |
| Deterministic eligibility | Python rule-matching, not LLM guessing |
| No PII stored | Session-only (in-memory), never written to disk |
| Scheme data attribution | Every record has `source_url` and `last_verified_date` |
| Transparent AI guidance | Every assistant response labelled "AI Guidance" in the UI |
| Uncertainty acknowledged | Missing profile fields listed; user told what to provide |

---

## 🧩 Module Guide

| File | What it does | Complexity |
|---|---|---|
| `data/schemes.json` | All scheme data — edit this to add/update schemes | ⭐ Easy |
| `backend/eligibility.py` | Checks user profile against scheme rules | ⭐⭐ Medium |
| `backend/disclaimer.py` | Detects eligibility responses and appends legal disclaimer | ⭐ Easy |
| `backend/validation.py` | Validates and sanitizes all user inputs | ⭐⭐ Medium |
| `backend/scheme_store.py` | Searches and retrieves schemes from JSON | ⭐ Easy |
| `backend/session.py` | In-memory session management (30-min TTL) | ⭐⭐ Medium |
| `backend/ai_assistant.py` | Calls IBM watsonx.ai; falls back to demo mode | ⭐⭐ Medium |
| `backend/app.py` | Flask routes — wires everything together | ⭐⭐ Medium |
| `backend/mcp_server.py` | MCP server exposing scheme data tools to Bob | ⭐⭐⭐ Advanced |
| `frontend/index.html` | Chat page HTML structure | ⭐ Easy |
| `frontend/style.css` | Visual styles | ⭐ Easy |
| `frontend/chat.js` | All frontend logic — messages, profile, API calls | ⭐⭐ Medium |
| `tests/test_eligibility.py` | Unit tests for eligibility + disclaimer | ⭐⭐ Medium |
| `tests/test_schemes.py` | Data integrity tests for schemes.json | ⭐ Easy |

---

## 📌 Known Limitations

1. **No live government data** — Scheme records are manually curated and may not reflect
   the latest eligibility rules or scheme status. Always verify on the official portal.

2. **Demo mode responses** — Without watsonx.ai credentials, responses are structured
   but not conversational. Configure API credentials for natural language responses.

3. **Translation quality** — LLM translations are fluent but may not be perfectly precise
   for legal or technical terms. Critical decisions should use official language resources.

4. **State-specific schemes** — Only central government schemes are included. State-level
   schemes (which vary significantly) are not in the dataset.

5. **Eligibility checker limitations** — The rule checker captures the main eligibility
   criteria. Complex, multi-condition, or income-band-based rules (like PMAY housing
   categories) are simplified.

6. **No accessibility audit** — The UI is designed with accessibility in mind but has not
   undergone a formal WCAG 2.1 AA audit.

7. **Single-process session store** — The in-memory session store works for single-process
   development. A production deployment would need Redis or similar.

---

## 🔮 Future Improvements

| Improvement | Benefit |
|---|---|
| Live MyScheme.gov.in API integration | Always-current scheme data |
| More regional languages (Tamil, Telugu, Bengali) | Broader reach |
| Voice input (Web Speech API) | Helps low-literacy users |
| State-level scheme database | Doubles scheme coverage |
| PWA / offline mode | Works in low-connectivity areas |
| WhatsApp / SMS integration | Reaches non-smartphone users |
| Scheme comparison side-by-side | Better decision support |
| Document checklist PDF download | Practical takeaway for users |
| Admin panel for scheme data updates | Non-technical maintenance |
| Production deployment with HTTPS | Secure public access |

---

## 🏛️ Scheme Dataset

The project includes 15 well-known central government schemes:

| Scheme | Category |
|---|---|
| PM Kisan Samman Nidhi | Agriculture |
| PM Fasal Bima Yojana | Agriculture |
| Kisan Credit Card | Agriculture |
| Ayushman Bharat PM-JAY | Health |
| PMAY Gramin | Housing |
| PMAY Urban | Housing |
| National Scholarship Portal | Education |
| PM Scholarship (Ex-Servicemen) | Education |
| Beti Bachao Beti Padhao | Women |
| PM Ujjwala Yojana | Women |
| IGNOAPS Old Age Pension | SeniorCitizens |
| MGNREGS | Employment |
| PM MUDRA Yojana | Employment |
| Skill India PMKVY | Employment |
| PM Jan Dhan Yojana | Finance |

---

*Built with ❤️ using IBM Bob | AI for Governance & Citizen Services*
