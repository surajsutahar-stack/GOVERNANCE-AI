"""
disclaimer.py
Legal disclaimer injector for the Citizen Services Assistant.

Two independent guardrails ensure every eligibility response carries a disclaimer:
  1. IBM Bob's rules file instructs the LLM to add a disclaimer.
  2. This module adds it in the backend — a second safety net.

Public API:
    DisclaimerInjector.needs_disclaimer(text) -> bool
    DisclaimerInjector.inject(text, lang_code) -> str
    DISCLAIMER_TEXTS  — dict of disclaimer text in all supported languages
"""

from __future__ import annotations

import re

# ---------------------------------------------------------------------------
# Disclaimer texts in all supported languages
# ---------------------------------------------------------------------------

DISCLAIMER_TEXTS: dict[str, str] = {
    "en": (
        "\n\n---\n"
        "⚠️ **IMPORTANT DISCLAIMER:** This is AI-generated guidance for "
        "informational purposes only. It is NOT an official government decision "
        "and does NOT guarantee that you will receive this benefit. Please verify "
        "eligibility and apply through the official government portal or your "
        "nearest Common Service Centre (CSC).\n"
        "---"
    ),
    "hi": (
        "\n\n---\n"
        "⚠️ **महत्वपूर्ण सूचना:** यह केवल सूचनात्मक उद्देश्यों के लिए "
        "AI-जनित मार्गदर्शन है। यह कोई आधिकारिक सरकारी निर्णय नहीं है और "
        "यह गारंटी नहीं देता कि आपको यह लाभ मिलेगा। कृपया आधिकारिक सरकारी "
        "पोर्टल या निकटतम जन सेवा केंद्र (CSC) पर पात्रता सत्यापित करें।\n"
        "---"
    ),
    "mr": (
        "\n\n---\n"
        "⚠️ **महत्त्वाची सूचना:** हे केवल माहितीच्या उद्देशाने AI-जनित "
        "मार्गदर्शन आहे. हा कोणताही अधिकृत सरकारी निर्णय नाही आणि यामुळे "
        "तुम्हाला हा लाभ मिळेलच असे नाही. कृपया अधिकृत सरकारी पोर्टलवर "
        "किंवा जवळच्या जन सेवा केंद्रावर (CSC) पात्रता तपासा.\n"
        "---"
    ),
    "gu": (
        "\n\n---\n"
        "⚠️ **મહત્વની નોંધ:** આ માત્ર માહિતી માટે AI-જનિત માર્ગદર્શન છે. "
        "આ કોઈ સત્તાવાર સરકારી નિર્ણય નથી અને આ ગેરેંટી આપતું નથી કે "
        "તમને આ લાભ મળશે. કૃપા કરીને સત્તાવાર સરકારી પોર્ટલ અથવા "
        "નજીકના જન સેવા કેન્દ્ર (CSC) પર પાત્રતા ચકાસો.\n"
        "---"
    ),
    "kn": (
        "\n\n---\n"
        "⚠️ **ಮುಖ್ಯ ಸೂಚನೆ:** ಇದು ಕೇವಲ ಮಾಹಿತಿ ಉದ್ದೇಶಗಳಿಗಾಗಿ AI-ಜನಿತ "
        "ಮಾರ್ಗದರ್ಶನ. ಇದು ಯಾವುದೇ ಅಧಿಕೃತ ಸರ್ಕಾರದ ನಿರ್ಧಾರ ಅಲ್ಲ ಮತ್ತು "
        "ನಿಮಗೆ ಈ ಸೌಲಭ್ಯ ಸಿಗುತ್ತದೆ ಎಂದು ಖಚಿತಪಡಿಸುವುದಿಲ್ಲ. ದಯವಿಟ್ಟು "
        "ಅಧಿಕೃತ ಸರ್ಕಾರಿ ಪೋರ್ಟಲ್ ಅಥವಾ ಹತ್ತಿರದ ಜನ ಸೇವಾ ಕೇಂದ್ರ (CSC) "
        "ದಲ್ಲಿ ಅರ್ಹತೆಯನ್ನು ಪರಿಶೀಲಿಸಿ.\n"
        "---"
    ),
}

# Phrases that indicate an eligibility-related response
_ELIGIBILITY_TRIGGER_PATTERNS: list[re.Pattern] = [
    re.compile(r"\beligib", re.IGNORECASE),
    re.compile(r"\bqualif", re.IGNORECASE),
    re.compile(r"\bmay be eligible", re.IGNORECASE),
    re.compile(r"\bmay not qualify", re.IGNORECASE),
    re.compile(r"\blikely eligible", re.IGNORECASE),
    re.compile(r"\bnot eligible", re.IGNORECASE),
    re.compile(r"\bपात्र", re.UNICODE),   # Hindi: paatr (eligible)
    re.compile(r"\bपात्रता", re.UNICODE), # Hindi: paatrta (eligibility)
    re.compile(r"\bपात्र", re.UNICODE),   # Marathi (same script)
    re.compile(r"\bपात्रता", re.UNICODE), # Marathi
    re.compile(r"\bపాత్రత", re.UNICODE),  # Telugu (eligibility)
    re.compile(r"\bಅರ್ಹತ", re.UNICODE),   # Kannada (eligibility)
    re.compile(r"\bપાત્ર", re.UNICODE),   # Gujarati
]

_DEFAULT_LANG = "en"


class DisclaimerInjector:
    """
    Detects whether a response contains eligibility-related content and,
    if so, appends the legal disclaimer in the appropriate language.
    """

    def needs_disclaimer(self, response_text: str) -> bool:
        """
        Return True if the response text contains eligibility-related content.

        Args:
            response_text: The raw response text from the AI.

        Returns:
            True if the disclaimer should be appended.
        """
        return any(p.search(response_text) for p in _ELIGIBILITY_TRIGGER_PATTERNS)

    def inject(self, response_text: str, lang_code: str = "en") -> str:
        """
        Append the disclaimer to response_text if it is eligibility-related
        and does not already contain a disclaimer marker.

        Args:
            response_text: The AI response text.
            lang_code:     ISO 639-1 language code (en, hi, mr, gu, kn).

        Returns:
            The response text, possibly with a disclaimer appended.
        """
        if not self.needs_disclaimer(response_text):
            return response_text

        # Avoid double-disclaimer if Bob already added one
        if "DISCLAIMER" in response_text or "सूचना" in response_text or "ಸೂಚನೆ" in response_text:
            return response_text

        disclaimer = DISCLAIMER_TEXTS.get(lang_code, DISCLAIMER_TEXTS[_DEFAULT_LANG])
        return response_text + disclaimer
