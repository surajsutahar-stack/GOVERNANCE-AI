"""
session.py
In-memory session management for the Citizen Services Assistant.

Stores per-session context:
  - User profile inputs
  - Preferred language
  - Last scheme discussed (for follow-up questions)

No data is ever written to disk.
Sessions expire after INACTIVITY_SECONDS of silence.

Public API:
    SessionManager.get(session_id) -> dict
    SessionManager.update(session_id, **kwargs) -> None
    SessionManager.clear(session_id) -> None
    SessionManager.cleanup_expired() -> None
"""

from __future__ import annotations

import time
import uuid
from typing import Any


INACTIVITY_SECONDS: int = 1800  # 30 minutes


class SessionManager:
    """
    Thread-safe-ish in-memory session store.
    (For a single-process Flask dev server this is sufficient.)
    """

    def __init__(self) -> None:
        self._store: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Public methods
    # ------------------------------------------------------------------

    def new_session(self) -> str:
        """Create a new session and return its ID."""
        session_id = str(uuid.uuid4())
        self._store[session_id] = {
            "created_at": time.time(),
            "last_active": time.time(),
            "user_profile": {},
            "preferred_language": "en",
            "last_scheme_id": None,
            "conversation_history": [],
        }
        return session_id

    def get(self, session_id: str) -> dict[str, Any]:
        """
        Return the session dict for session_id.
        Returns an empty dict if the session does not exist or has expired.
        """
        self.cleanup_expired()
        session = self._store.get(session_id)
        if session is None:
            return {}
        session["last_active"] = time.time()
        return session

    def update(self, session_id: str, **kwargs: Any) -> None:
        """
        Update one or more fields in the session.
        Creates the session if it does not exist.

        Recognised kwargs:
          user_profile (dict), preferred_language (str),
          last_scheme_id (str|None), conversation_history (list)
        """
        if session_id not in self._store:
            self.new_session()
            # Re-use the requested id (simple override for deterministic testing)
            self._store[session_id] = self._store.pop(
                next(iter(self._store))
            )

        session = self._store[session_id]
        session["last_active"] = time.time()

        for key, value in kwargs.items():
            if key in session:
                session[key] = value

    def update_profile(self, session_id: str, profile_patch: dict[str, Any]) -> None:
        """Merge profile_patch into the session's existing user_profile."""
        session = self._store.get(session_id)
        if session is None:
            return
        session["user_profile"].update(profile_patch)
        session["last_active"] = time.time()

    def clear(self, session_id: str) -> None:
        """Remove a session entirely."""
        self._store.pop(session_id, None)

    def cleanup_expired(self) -> None:
        """Remove all sessions that have been inactive longer than INACTIVITY_SECONDS."""
        now = time.time()
        expired = [
            sid
            for sid, data in self._store.items()
            if now - data.get("last_active", 0) > INACTIVITY_SECONDS
        ]
        for sid in expired:
            del self._store[sid]

    def exists(self, session_id: str) -> bool:
        """Return True if the session exists and has not expired."""
        self.cleanup_expired()
        return session_id in self._store
