"""
ai_assistant.py
AI assistant module for the Citizen Services Assistant.

This module is responsible for:
  1. Building the prompt that is sent to IBM Bob / watsonx.ai
  2. Calling the AI model API
  3. Returning the plain-text response

IBM Bob acts as the natural language layer:
  - Understanding free-text citizen questions
  - Explaining eligibility results in plain language
  - Generating multilingual responses
  - Suggesting relevant schemes

The eligibility LOGIC lives in eligibility.py (deterministic Python code).
The AI only explains the result — it does not compute it.

Configuration:
  Set environment variables before running:
    WATSONX_API_KEY   — your IBM watsonx.ai API key
    WATSONX_PROJECT_ID — your watsonx.ai project ID
    WATSONX_URL       — watsonx.ai API endpoint URL
                        (default: https://us-south.ml.cloud.ibm.com)

  If these are not set, the assistant uses a DEMO MODE that returns
  a helpful plain-text response without calling the real API.
  Demo mode is useful for local testing without an IBM account.
"""

from __future__ import annotations

import json
import os
import re
from typing import Any

import urllib.request
import urllib.error


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

WATSONX_API_KEY: str = os.environ.get("WATSONX_API_KEY", "")
WATSONX_PROJECT_ID: str = os.environ.get("WATSONX_PROJECT_ID", "")
WATSONX_URL: str = os.environ.get(
    "WATSONX_URL", "https://us-south.ml.cloud.ibm.com"
)
MODEL_ID: str = os.environ.get("WATSONX_MODEL_ID", "ibm/granite-3-8b-instruct")

_DEMO_MODE: bool = not (WATSONX_API_KEY and WATSONX_PROJECT_ID)


# ---------------------------------------------------------------------------
# System prompt template
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a helpful and empathetic Citizen Services Guide for India.
Your only purpose is to help citizens understand government schemes and public services.

Rules you must always follow:
1. Only discuss government schemes and public services.
2. Never guarantee eligibility or benefit approval.
3. Always include a disclaimer when discussing eligibility.
4. Use simple language — avoid jargon.
5. Only cite information that comes from the scheme data provided to you.
6. If you do not know something, say so clearly.
7. Respond entirely in the citizen's preferred language: {language_name}.
8. Keep official scheme names in English (or transliterate).

Standard disclaimer to include with eligibility responses:
⚠️ DISCLAIMER: This is AI guidance only and is NOT an official government decision.
Please verify through the official portal or a Common Service Centre (CSC).
"""

LANGUAGE_NAMES: dict[str, str] = {
    "en": "English",
    "hi": "Hindi",
    "mr": "Marathi",
    "gu": "Gujarati",
    "kn": "Kannada",
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class AIAssistant:
    """
    Wraps the IBM watsonx.ai API call.
    Falls back to demo mode when credentials are not configured.
    """

    def answer(
        self,
        user_message: str,
        scheme_context: dict[str, Any] | None = None,
        eligibility_result: dict[str, Any] | None = None,
        conversation_history: list[dict] | None = None,
        language: str = "en",
    ) -> str:
        """
        Generate a response to the user's message.

        Args:
            user_message:       The citizen's question or request.
            scheme_context:     Optional scheme data dict to include in context.
            eligibility_result: Optional eligibility result dict to explain.
            conversation_history: Previous turns [{"role":"user","content":"..."},...]
            language:           ISO language code for the response.

        Returns:
            Plain-text response string.
        """
        prompt = self._build_prompt(
            user_message, scheme_context, eligibility_result,
            conversation_history or [], language
        )

        if _DEMO_MODE:
            return self._demo_response(user_message, scheme_context, eligibility_result, language)

        return self._call_watsonx(prompt)

    # ------------------------------------------------------------------
    # Prompt builder
    # ------------------------------------------------------------------

    def _build_prompt(
        self,
        user_message: str,
        scheme_context: dict | None,
        eligibility_result: dict | None,
        history: list[dict],
        language: str,
    ) -> str:
        lang_name = LANGUAGE_NAMES.get(language, "English")
        system = SYSTEM_PROMPT.format(language_name=lang_name)

        parts: list[str] = [f"<system>\n{system}\n</system>\n"]

        # Inject scheme context if available
        if scheme_context:
            parts.append(
                "<scheme_data>\n"
                + json.dumps(scheme_context, ensure_ascii=False, indent=2)
                + "\n</scheme_data>\n"
            )

        # Inject eligibility result if available
        if eligibility_result:
            parts.append(
                "<eligibility_result>\n"
                + json.dumps(eligibility_result, ensure_ascii=False, indent=2)
                + "\n</eligibility_result>\n"
                "<instruction>Explain this eligibility result to the citizen in "
                f"simple {lang_name}. Tell them which rules passed and which did not. "
                "Mention any missing information. Always end with the disclaimer.</instruction>\n"
            )

        # Add conversation history (last 6 turns to manage context)
        for turn in history[-6:]:
            role = "Human" if turn.get("role") == "user" else "Assistant"
            parts.append(f"{role}: {turn.get('content', '')}\n")

        parts.append(f"Human: {user_message}\nAssistant:")

        return "".join(parts)

    # ------------------------------------------------------------------
    # watsonx.ai API call
    # ------------------------------------------------------------------

    def _call_watsonx(self, prompt: str) -> str:
        """Call the IBM watsonx.ai text generation API."""
        # First get an IAM token
        token = self._get_iam_token()
        if not token:
            return (
                "I'm sorry — the AI service is temporarily unavailable. "
                "Please try again shortly or visit india.gov.in for official scheme information."
            )

        url = f"{WATSONX_URL}/ml/v1/text/generation?version=2023-05-29"
        payload = {
            "model_id": MODEL_ID,
            "input": prompt,
            "parameters": {
                "decoding_method": "greedy",
                "max_new_tokens": 800,
                "stop_sequences": ["Human:", "<human>"],
                "repetition_penalty": 1.1,
            },
            "project_id": WATSONX_PROJECT_ID,
        }

        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=body,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {token}",
            },
            method="POST",
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                return data["results"][0]["generated_text"].strip()
        except urllib.error.HTTPError as exc:
            return (
                f"The AI service returned an error ({exc.code}). "
                "Please try again or contact support."
            )
        except Exception:
            return (
                "I'm sorry — there was a problem reaching the AI service. "
                "Please try again shortly."
            )

    def _get_iam_token(self) -> str:
        """Exchange the API key for an IBM IAM bearer token."""
        url = "https://iam.cloud.ibm.com/identity/token"
        data = (
            f"grant_type=urn:ibm:params:oauth:grant-type:apikey"
            f"&apikey={WATSONX_API_KEY}"
        ).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                return result.get("access_token", "")
        except Exception:
            return ""

    # ------------------------------------------------------------------
    # Demo mode (no API credentials needed)
    # ------------------------------------------------------------------

    def _demo_response(
        self,
        user_message: str,
        scheme_context: dict | None,
        eligibility_result: dict | None,
        language: str,
    ) -> str:
        """
        Return a canned but informative demo response.
        Used when watsonx.ai credentials are not configured.
        """
        msg_lower = user_message.lower()

        # Eligibility explanation
        if eligibility_result:
            status = eligibility_result.get("match_status", "")
            name = eligibility_result.get("scheme_name", "this scheme")
            rules = eligibility_result.get("rules_checked", [])
            missing = eligibility_result.get("missing_fields", [])

            passed = [r for r in rules if r.get("passed")]
            failed = [r for r in rules if not r.get("passed")]

            lines: list[str] = []
            if status == "likely_eligible":
                lines.append(f"✅ Based on the information you provided, you may be eligible for **{name}**.")
            elif status == "may_not_qualify":
                lines.append(f"⚠️ Based on the information you provided, you may **not qualify** for **{name}**.")
            else:
                lines.append(f"ℹ️ I need more information to assess your eligibility for **{name}**.")

            if passed:
                lines.append("\n**Criteria you meet:**")
                for r in passed:
                    lines.append(f"  ✅ {r['rule']}: {r['user_value']} (required: {r['required']})")

            if failed:
                lines.append("\n**Criteria you do not meet:**")
                for r in failed:
                    lines.append(f"  ❌ {r['rule']}: {r['user_value']} (required: {r['required']})")
                    if r.get("note"):
                        lines.append(f"     {r['note']}")

            if missing:
                lines.append(f"\n**Information not provided:** {', '.join(missing)}")
                lines.append("Providing these details would give a more complete assessment.")

            return "\n".join(lines)

        # Scheme details response
        if scheme_context:
            name = scheme_context.get("scheme_name", "this scheme")
            desc = scheme_context.get("description_simple", "")
            docs = scheme_context.get("required_documents", [])
            how = scheme_context.get("how_to_apply", "")
            url = scheme_context.get("apply_portal_url", "")

            lines = [f"**{name}**\n", desc]
            if docs:
                lines.append("\n**Documents typically required:**")
                for i, doc in enumerate(docs, 1):
                    lines.append(f"  {i}. {doc}")
            if how:
                lines.append(f"\n**How to apply:**\n{how}")
            if url:
                lines.append(f"\n🔗 [Apply on official portal]({url})")
            return "\n".join(lines)

        # Generic helpful message
        if any(w in msg_lower for w in ["scheme", "benefit", "yojana", "help"]):
            return (
                "I can help you discover and understand government schemes! "
                "You can:\n"
                "• **Browse schemes** by selecting a category (Agriculture, Health, Housing, etc.)\n"
                "• **Search** for a scheme by name or keyword\n"
                "• **Check eligibility** by filling in your profile details\n"
                "• **Ask about documents** required for any scheme\n\n"
                "What would you like to know?"
            )

        return (
            "I'm here to help you with Indian government schemes and public services. "
            "Try asking me about schemes for farmers, students, senior citizens, or housing. "
            "You can also fill in your profile details to check eligibility."
        )
