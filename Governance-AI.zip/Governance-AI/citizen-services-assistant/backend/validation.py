"""
validation.py
Input validation helpers for the Citizen Services Assistant.

All user inputs are validated here before being processed.
Validation runs on the backend (never trust frontend-only validation).

Public API:
    validate_profile(raw_profile) -> tuple[dict, list[str]]
    validate_message(text) -> tuple[str, str | None]
    SUPPORTED_LANGUAGES — frozenset of supported language codes
    VALID_STATES — frozenset of valid Indian state/UT names
"""

from __future__ import annotations

import re
from typing import Any


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SUPPORTED_LANGUAGES: frozenset[str] = frozenset({"en", "hi", "mr", "gu", "kn"})

VALID_STATES: frozenset[str] = frozenset({
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh",
    "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka",
    "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram",
    "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu",
    "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal",
    # Union Territories
    "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu",
    "Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry",
})

VALID_SOCIAL_CATEGORIES: frozenset[str] = frozenset({"General", "SC", "ST", "OBC", "EWS"})

VALID_GENDERS: frozenset[str] = frozenset({"Male", "Female", "Transgender", "Other", "Prefer not to say"})

_MAX_MESSAGE_LENGTH: int = 500
_MAX_OCCUPATION_LENGTH: int = 100
_HTML_TAG_PATTERN: re.Pattern = re.compile(r"<[^>]+>")


# ---------------------------------------------------------------------------
# Public validators
# ---------------------------------------------------------------------------

def validate_message(text: Any) -> tuple[str, str | None]:
    """
    Validate a free-text user message.

    Args:
        text: Raw input from the user.

    Returns:
        (cleaned_text, error_message)
        error_message is None if valid, otherwise a human-readable error string.
    """
    if not isinstance(text, str):
        return "", "Message must be a text string."

    cleaned = _sanitize_text(text).strip()

    if not cleaned:
        return "", "Please enter a message to continue."

    if len(cleaned) > _MAX_MESSAGE_LENGTH:
        return (
            cleaned[:_MAX_MESSAGE_LENGTH],
            f"Your message is too long. Please keep it under {_MAX_MESSAGE_LENGTH} characters.",
        )

    return cleaned, None


def validate_language(lang: Any) -> tuple[str, str | None]:
    """
    Validate a language code.

    Returns:
        (lang_code, error_message). Falls back to "en" on invalid input.
    """
    if not isinstance(lang, str):
        return "en", "Invalid language code. Defaulting to English."

    lang = lang.strip().lower()
    if lang not in SUPPORTED_LANGUAGES:
        return "en", (
            f"Language '{lang}' is not supported. "
            f"Supported languages: {', '.join(sorted(SUPPORTED_LANGUAGES))}. "
            "Defaulting to English."
        )
    return lang, None


def validate_profile(raw: Any) -> tuple[dict[str, Any], list[str]]:
    """
    Validate and clean a user profile dict.

    Args:
        raw: Raw profile dict from the request body. May be None or partial.

    Returns:
        (cleaned_profile, errors)
        cleaned_profile contains only the valid fields.
        errors is a list of human-readable error strings (may be empty).
    """
    if raw is None:
        return {}, []

    if not isinstance(raw, dict):
        return {}, ["Profile must be a JSON object."]

    cleaned: dict[str, Any] = {}
    errors: list[str] = []

    # ---- Age ----
    age = raw.get("age")
    if age is not None:
        age_val, age_err = _validate_age(age)
        if age_err:
            errors.append(age_err)
        else:
            cleaned["age"] = age_val

    # ---- Gender ----
    gender = raw.get("gender")
    if gender is not None:
        gender_val, gender_err = _validate_gender(gender)
        if gender_err:
            errors.append(gender_err)
        else:
            cleaned["gender"] = gender_val

    # ---- Occupation ----
    occupation = raw.get("occupation")
    if occupation is not None:
        occ_val, occ_err = _validate_occupation(occupation)
        if occ_err:
            errors.append(occ_err)
        else:
            cleaned["occupation"] = occ_val

    # ---- Annual income ----
    income = raw.get("annual_income_inr")
    if income is not None:
        inc_val, inc_err = _validate_income(income)
        if inc_err:
            errors.append(inc_err)
        else:
            cleaned["annual_income_inr"] = inc_val

    # ---- State ----
    state = raw.get("state")
    if state is not None:
        state_val, state_err = _validate_state(state)
        if state_err:
            errors.append(state_err)
        else:
            cleaned["state"] = state_val

    # ---- Social category ----
    category = raw.get("social_category")
    if category is not None:
        cat_val, cat_err = _validate_social_category(category)
        if cat_err:
            errors.append(cat_err)
        else:
            cleaned["social_category"] = cat_val

    return cleaned, errors


# ---------------------------------------------------------------------------
# Private field validators
# ---------------------------------------------------------------------------

def _sanitize_text(text: str) -> str:
    """Remove HTML tags and strip leading/trailing whitespace."""
    return _HTML_TAG_PATTERN.sub("", text).strip()


def _validate_age(age: Any) -> tuple[int | None, str | None]:
    try:
        age_int = int(age)
    except (ValueError, TypeError):
        return None, f"Age must be a whole number. Received: '{age}'."
    if age_int < 0 or age_int > 120:
        return None, f"Age must be between 0 and 120. Received: {age_int}."
    return age_int, None


def _validate_gender(gender: Any) -> tuple[str | None, str | None]:
    if not isinstance(gender, str):
        return None, "Gender must be a text value."
    gender = gender.strip()
    if not gender:
        return None, None  # Empty is fine — field is optional
    # Case-insensitive match against valid genders
    matched = next(
        (g for g in VALID_GENDERS if g.lower() == gender.lower()), None
    )
    if matched is None:
        return (
            gender,  # Keep the user's value; do not reject unknown self-descriptions
            None,
        )
    return matched, None


def _validate_occupation(occ: Any) -> tuple[str | None, str | None]:
    if not isinstance(occ, str):
        return None, "Occupation must be a text value."
    occ = _sanitize_text(occ)
    if len(occ) > _MAX_OCCUPATION_LENGTH:
        return None, f"Occupation must be under {_MAX_OCCUPATION_LENGTH} characters."
    return occ if occ else None, None


def _validate_income(income: Any) -> tuple[int | None, str | None]:
    try:
        income_int = int(income)
    except (ValueError, TypeError):
        return None, f"Annual income must be a whole number. Received: '{income}'."
    if income_int < 0:
        return None, "Annual income cannot be negative."
    if income_int > 100_000_000:
        return None, "Annual income value seems too large. Please enter it in Indian Rupees."
    return income_int, None


def _validate_state(state: Any) -> tuple[str | None, str | None]:
    if not isinstance(state, str):
        return None, "State must be a text value."
    state = state.strip()
    if not state:
        return None, None  # Optional field
    matched = next(
        (s for s in VALID_STATES if s.lower() == state.lower()), None
    )
    if matched is None:
        return (
            state,
            f"'{state}' is not a recognised Indian state or union territory. "
            "Please check the spelling.",
        )
    return matched, None


def _validate_social_category(cat: Any) -> tuple[str | None, str | None]:
    if not isinstance(cat, str):
        return None, "Social category must be a text value."
    cat = cat.strip().upper()
    if not cat:
        return None, None
    # Normalise to title-case for General, keep uppercase for SC/ST/OBC/EWS
    normalised = "General" if cat == "GENERAL" else cat
    if normalised not in VALID_SOCIAL_CATEGORIES:
        return None, (
            f"'{cat}' is not a recognised social category. "
            f"Valid categories: {', '.join(sorted(VALID_SOCIAL_CATEGORIES))}."
        )
    return normalised, None
