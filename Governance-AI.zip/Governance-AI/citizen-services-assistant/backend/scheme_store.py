"""
scheme_store.py
Simple wrapper around schemes.json that provides in-memory search and
retrieval without needing the MCP server (used directly by the Flask backend).

The MCP server uses the same logic but exposes it via the JSON-RPC protocol
for IBM Bob to call. This module is for the Flask backend's own use.
"""

from __future__ import annotations

import json
import os
from typing import Any


_DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "schemes.json")


def _load() -> list[dict[str, Any]]:
    with open(_DATA_PATH, encoding="utf-8") as f:
        raw = json.load(f)
    return raw["schemes"]


_SCHEMES: list[dict[str, Any]] = _load()


def search_schemes(
    keyword: str = "",
    category: str = "",
    state: str = "",
) -> list[dict[str, Any]]:
    """Return summary dicts for schemes matching keyword/category/state filters."""
    keyword_lower = keyword.strip().lower()
    category_lower = category.strip().lower()
    state_lower = state.strip().lower()
    results = []
    for scheme in _SCHEMES:
        if category_lower and scheme["category"].lower() != category_lower:
            continue
        if state_lower and state_lower not in ("all", ""):
            applicable = [s.lower() for s in scheme["applicable_states"]]
            if "all" not in applicable and state_lower not in applicable:
                continue
        if keyword_lower:
            searchable = " ".join([
                scheme["scheme_name"],
                scheme["description_simple"],
                scheme["description_official"],
                scheme["category"],
                scheme["department"],
            ]).lower()
            if keyword_lower not in searchable:
                continue
        results.append({
            "scheme_id": scheme["scheme_id"],
            "scheme_name": scheme["scheme_name"],
            "department": scheme["department"],
            "category": scheme["category"],
            "description_simple": scheme["description_simple"],
            "apply_portal_url": scheme["apply_portal_url"],
        })
    return results


def get_scheme_by_id(scheme_id: str) -> dict[str, Any] | None:
    """Return the full scheme record for the given scheme_id, or None."""
    sid = scheme_id.strip().lower()
    for scheme in _SCHEMES:
        if scheme["scheme_id"].lower() == sid:
            return scheme
    return None


def list_categories() -> list[str]:
    """Return sorted list of distinct scheme categories."""
    return sorted({s["category"] for s in _SCHEMES})


def all_schemes() -> list[dict[str, Any]]:
    """Return all scheme records."""
    return list(_SCHEMES)
