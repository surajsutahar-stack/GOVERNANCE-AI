"""
eligibility.py
Deterministic rule-based eligibility checker for the Citizen Services Assistant.

Design principle:
  IBM Bob's LLM explains the result in plain language.
  This module DETERMINES the result — predictably and auditably.
  The LLM never makes eligibility decisions; it only narrates them.

Public API:
    check_eligibility(user_profile, scheme) -> EligibilityResult
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class RuleCheck:
    """Records the outcome of checking a single eligibility rule."""
    rule: str           # Human-readable rule name, e.g. "Age"
    required: str       # What the scheme requires, as a string
    user_value: str     # What the user provided (or "Not provided")
    passed: bool        # True if the rule is satisfied
    note: str = ""      # Optional extra explanation


@dataclass
class EligibilityResult:
    """
    The full result of an eligibility check for one scheme.

    match_status values:
      "likely_eligible"    — all checked rules passed
      "may_not_qualify"    — one or more rules failed
      "insufficient_data"  — not enough user data to check all rules
    """
    scheme_id: str
    scheme_name: str
    match_status: str                      # "likely_eligible" | "may_not_qualify" | "insufficient_data"
    rules_checked: list[RuleCheck] = field(default_factory=list)
    missing_fields: list[str] = field(default_factory=list)
    summary: str = ""                      # One-sentence plain-English summary


# ---------------------------------------------------------------------------
# Eligibility checker
# ---------------------------------------------------------------------------

class EligibilityChecker:
    """
    Checks a user profile against the eligibility_rules of a scheme record.

    Usage:
        checker = EligibilityChecker()
        result = checker.check(user_profile, scheme)
    """

    # Fields in the user profile we know how to check
    CHECKABLE_RULES = ("age", "gender", "occupation", "income", "social_category", "state")

    def check(
        self,
        user_profile: dict[str, Any],
        scheme: dict[str, Any],
    ) -> EligibilityResult:
        """
        Run all eligibility checks and return an EligibilityResult.

        Args:
            user_profile: Dict with optional keys:
                age (int), gender (str), occupation (str),
                annual_income_inr (int), state (str), social_category (str)
            scheme: Full scheme record dict (from schemes.json)

        Returns:
            EligibilityResult with rules_checked and match_status populated.
        """
        rules = scheme.get("eligibility_rules", {})
        checks: list[RuleCheck] = []
        missing: list[str] = []
        any_failed = False

        # Each private checker returns (RuleCheck | None, is_missing: bool).
        # is_missing=True  → scheme requires this field but user didn't provide it.
        # is_missing=False → scheme has no restriction; field can be safely skipped.

        # ---- Age ----
        age_check, age_missing = self._check_age(user_profile, rules)
        if age_missing:
            missing.append("age")
        elif age_check is not None:
            checks.append(age_check)
            if not age_check.passed:
                any_failed = True

        # ---- Gender ----
        gender_check, gender_missing = self._check_gender(user_profile, rules)
        if gender_missing:
            missing.append("gender")
        elif gender_check is not None:
            checks.append(gender_check)
            if not gender_check.passed:
                any_failed = True

        # ---- Occupation ----
        occ_check, occ_missing = self._check_occupation(user_profile, rules)
        if occ_missing:
            missing.append("occupation")
        elif occ_check is not None:
            checks.append(occ_check)
            if not occ_check.passed:
                any_failed = True

        # ---- Income ----
        income_check, income_missing = self._check_income(user_profile, rules)
        if income_missing:
            missing.append("annual_income_inr")
        elif income_check is not None:
            checks.append(income_check)
            if not income_check.passed:
                any_failed = True

        # ---- Social category ----
        cat_check, cat_missing = self._check_social_category(user_profile, rules)
        if cat_missing:
            missing.append("social_category")
        elif cat_check is not None:
            checks.append(cat_check)
            if not cat_check.passed:
                any_failed = True

        # ---- State ----
        state_check, state_missing = self._check_state(user_profile, rules)
        if state_missing:
            missing.append("state")
        elif state_check is not None:
            checks.append(state_check)
            if not state_check.passed:
                any_failed = True

        # ---- Determine overall status ----
        if any_failed:
            status = "may_not_qualify"
        elif missing:
            status = "insufficient_data"
        else:
            status = "likely_eligible"

        summary = self._build_summary(status, scheme["scheme_name"], missing)

        return EligibilityResult(
            scheme_id=scheme["scheme_id"],
            scheme_name=scheme["scheme_name"],
            match_status=status,
            rules_checked=checks,
            missing_fields=missing,
            summary=summary,
        )

    # ------------------------------------------------------------------
    # Private rule checkers
    # Each returns (RuleCheck | None, is_missing: bool).
    #   (check, False) → no restriction on this field; silently skip
    #   (check, True)  → scheme requires this field but user omitted it
    #   (RuleCheck, False) → rule was checked; inspect .passed for outcome
    # ------------------------------------------------------------------

    def _check_age(
        self, profile: dict[str, Any], rules: dict[str, Any]
    ) -> tuple[RuleCheck | None, bool]:
        min_age: int | None = rules.get("min_age")
        max_age: int | None = rules.get("max_age")

        # Scheme has no age restriction → skip silently, not missing
        if min_age is None and max_age is None:
            return None, False

        user_age = profile.get("age")
        if user_age is None:
            return None, True  # Scheme requires age but user didn't provide it

        user_age = int(user_age)
        parts: list[str] = []
        if min_age is not None:
            parts.append(f"≥ {min_age}")
        if max_age is not None:
            parts.append(f"≤ {max_age}")
        required_str = " and ".join(parts) + " years"

        passed = True
        note = ""
        if min_age is not None and user_age < min_age:
            passed = False
            note = f"Your age ({user_age}) is below the minimum ({min_age})."
        if max_age is not None and user_age > max_age:
            passed = False
            note = f"Your age ({user_age}) exceeds the maximum ({max_age})."

        return RuleCheck(
            rule="Age",
            required=required_str,
            user_value=str(user_age),
            passed=passed,
            note=note,
        ), False

    def _check_gender(
        self, profile: dict[str, Any], rules: dict[str, Any]
    ) -> tuple[RuleCheck | None, bool]:
        required_gender: str = rules.get("gender", "Any")

        # No gender restriction → skip silently
        if required_gender in ("Any", "any", "ANY", ""):
            return None, False

        user_gender = profile.get("gender")
        if user_gender is None:
            return None, True  # Scheme requires gender but user didn't provide it

        passed = user_gender.strip().lower() == required_gender.strip().lower()
        note = "" if passed else f"This scheme is for {required_gender} applicants only."

        return RuleCheck(
            rule="Gender",
            required=required_gender,
            user_value=user_gender,
            passed=passed,
            note=note,
        ), False

    def _check_occupation(
        self, profile: dict[str, Any], rules: dict[str, Any]
    ) -> tuple[RuleCheck | None, bool]:
        required_occupations: list[str] = rules.get("occupation", ["ANY"])

        # No occupation restriction → skip silently
        if "ANY" in required_occupations or "any" in required_occupations:
            return None, False

        user_occ = profile.get("occupation")
        if user_occ is None:
            return None, True  # Scheme requires occupation but user didn't provide it

        user_occ_lower = user_occ.strip().lower()
        required_lower = [o.lower() for o in required_occupations]

        # Partial matching: "farmer" matches "Small farmer" etc.
        passed = any(
            (user_occ_lower in req) or (req in user_occ_lower)
            for req in required_lower
        )

        note = (
            ""
            if passed
            else f"This scheme requires occupation: {', '.join(required_occupations)}."
        )

        return RuleCheck(
            rule="Occupation",
            required=", ".join(required_occupations),
            user_value=user_occ,
            passed=passed,
            note=note,
        ), False

    def _check_income(
        self, profile: dict[str, Any], rules: dict[str, Any]
    ) -> tuple[RuleCheck | None, bool]:
        max_income: int | None = rules.get("income_max_annual_inr")

        # No income restriction → skip silently
        if max_income is None:
            return None, False

        user_income = profile.get("annual_income_inr")
        if user_income is None:
            return None, True  # Scheme has income limit but user didn't provide income

        user_income = int(user_income)
        passed = user_income <= max_income
        note = (
            ""
            if passed
            else (
                f"Your income (₹{user_income:,}) exceeds the maximum "
                f"allowed (₹{max_income:,})."
            )
        )

        return RuleCheck(
            rule="Annual Income",
            required=f"≤ ₹{max_income:,}",
            user_value=f"₹{user_income:,}",
            passed=passed,
            note=note,
        ), False

    def _check_social_category(
        self, profile: dict[str, Any], rules: dict[str, Any]
    ) -> tuple[RuleCheck | None, bool]:
        required_cats: list[str] = rules.get("social_category", ["ANY"])

        # No category restriction → skip silently
        if "ANY" in required_cats:
            return None, False

        user_cat = profile.get("social_category")
        if user_cat is None:
            return None, True  # Scheme restricts category but user didn't provide it

        user_cat_norm = user_cat.strip().upper()
        required_norm = [c.strip().upper() for c in required_cats]

        passed = user_cat_norm in required_norm
        note = (
            ""
            if passed
            else f"This scheme is for: {', '.join(required_cats)} categories."
        )

        return RuleCheck(
            rule="Social Category",
            required=", ".join(required_cats),
            user_value=user_cat,
            passed=passed,
            note=note,
        ), False

    def _check_state(
        self, profile: dict[str, Any], rules: dict[str, Any]
    ) -> tuple[RuleCheck | None, bool]:
        state_required: str = rules.get("state_required", "ALL")

        # Available everywhere → skip silently
        if state_required.upper() == "ALL":
            return None, False

        user_state = profile.get("state")
        if user_state is None:
            return None, True  # Scheme is state-restricted but user didn't provide state

        passed = user_state.strip().lower() == state_required.strip().lower()
        note = (
            ""
            if passed
            else f"This scheme is only available in {state_required}."
        )

        return RuleCheck(
            rule="State",
            required=state_required,
            user_value=user_state,
            passed=passed,
            note=note,
        ), False

    # ------------------------------------------------------------------
    # Summary builder
    # ------------------------------------------------------------------

    def _build_summary(
        self,
        status: str,
        scheme_name: str,
        missing: list[str],
    ) -> str:
        if status == "likely_eligible":
            return (
                f"Based on the information you provided, you may be eligible for "
                f"{scheme_name}. Please verify on the official portal."
            )
        if status == "may_not_qualify":
            return (
                f"Based on the information you provided, you may not qualify for "
                f"{scheme_name}. Review the failed checks above for details."
            )
        # insufficient_data
        missing_readable = ", ".join(missing)
        return (
            f"I could not fully assess your eligibility for {scheme_name} because "
            f"the following information was not provided: {missing_readable}. "
            f"Please provide these details for a more complete check."
        )
