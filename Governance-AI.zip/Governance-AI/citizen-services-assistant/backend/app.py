"""
app.py
Flask backend for the AI-Powered Citizen Services Assistant.

Entry point — starts the web server and exposes three endpoints:
  GET  /                 → Serves the chat HTML page
  POST /chat             → Handles a citizen's message; returns AI response
  GET  /schemes/categories → Returns available scheme categories

Run:
  cd citizen-services-assistant
  python backend/app.py

The server starts on http://127.0.0.1:5000 by default.
"""

from __future__ import annotations

import json
import os
import sys

# Allow imports from backend package when running as __main__
sys.path.insert(0, os.path.dirname(__file__))

from flask import Flask, request, jsonify, send_from_directory, Response

from eligibility import EligibilityChecker
from disclaimer import DisclaimerInjector
from session import SessionManager
from validation import validate_message, validate_language, validate_profile
from scheme_store import search_schemes, get_scheme_by_id, list_categories
from ai_assistant import AIAssistant

# ---------------------------------------------------------------------------
# App setup
# ---------------------------------------------------------------------------

app = Flask(__name__, static_folder=None)

_checker = EligibilityChecker()
_disclaimer = DisclaimerInjector()
_sessions = SessionManager()
_ai = AIAssistant()

FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")

# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def index() -> Response:
    """Serve the chat interface HTML page."""
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/<path:filename>")
def static_files(filename: str) -> Response:
    """Serve CSS and JS files from the frontend directory."""
    return send_from_directory(FRONTEND_DIR, filename)


@app.route("/schemes/categories", methods=["GET"])
def get_categories() -> Response:
    """Return the list of available scheme categories."""
    return jsonify({"categories": list_categories()})


@app.route("/schemes/search", methods=["GET"])
def search() -> Response:
    """
    Search schemes.
    Query params: keyword, category, state
    """
    keyword = request.args.get("keyword", "")
    category = request.args.get("category", "")
    state = request.args.get("state", "")
    results = search_schemes(keyword=keyword, category=category, state=state)
    return jsonify({"schemes": results, "count": len(results)})


@app.route("/chat", methods=["POST"])
def chat() -> Response:
    """
    Main chat endpoint.

    Expected JSON body:
    {
        "message":    string (required),
        "session_id": string (optional — creates new session if absent),
        "language":   string (optional — default "en"),
        "profile":    object (optional — user profile fields),
        "scheme_id":  string (optional — scheme to focus the response on)
    }

    Response JSON:
    {
        "response":          string,
        "session_id":        string,
        "disclaimer_shown":  bool,
        "validation_errors": list[string],
        "scheme_context":    object | null
    }
    """
    body = request.get_json(silent=True) or {}

    # ---- Validate message ----
    raw_message = body.get("message", "")
    message, msg_error = validate_message(raw_message)
    if msg_error and not message:
        return jsonify({"error": msg_error, "response": msg_error}), 400

    # ---- Validate language ----
    raw_lang = body.get("language", "en")
    language, lang_warning = validate_language(raw_lang)

    # ---- Validate profile ----
    raw_profile = body.get("profile", {})
    clean_profile, profile_errors = validate_profile(raw_profile)

    # ---- Session management ----
    session_id = body.get("session_id", "")
    if not session_id or not _sessions.exists(session_id):
        session_id = _sessions.new_session()

    session = _sessions.get(session_id)

    # Merge validated profile into session (accumulate fields across turns)
    if clean_profile:
        _sessions.update_profile(session_id, clean_profile)
        session = _sessions.get(session_id)

    # Update language preference
    _sessions.update(session_id, preferred_language=language)
    effective_profile: dict = session.get("user_profile", {})

    # ---- Determine scheme context ----
    scheme_id = body.get("scheme_id") or session.get("last_scheme_id")
    scheme_context = None
    eligibility_result_dict = None

    if scheme_id:
        scheme = get_scheme_by_id(scheme_id)
        if scheme:
            scheme_context = scheme
            _sessions.update(session_id, last_scheme_id=scheme_id)

            # Run eligibility check if the profile has any data
            if effective_profile and _is_eligibility_query(message):
                result = _checker.check(effective_profile, scheme)
                eligibility_result_dict = {
                    "scheme_id": result.scheme_id,
                    "scheme_name": result.scheme_name,
                    "match_status": result.match_status,
                    "rules_checked": [
                        {
                            "rule": r.rule,
                            "required": r.required,
                            "user_value": r.user_value,
                            "passed": r.passed,
                            "note": r.note,
                        }
                        for r in result.rules_checked
                    ],
                    "missing_fields": result.missing_fields,
                    "summary": result.summary,
                }

    # ---- Update conversation history ----
    history: list[dict] = session.get("conversation_history", [])
    history.append({"role": "user", "content": message})

    # ---- Call AI assistant ----
    ai_response = _ai.answer(
        user_message=message,
        scheme_context=scheme_context,
        eligibility_result=eligibility_result_dict,
        conversation_history=history,
        language=language,
    )

    # ---- Inject disclaimer (second safety net) ----
    final_response = _disclaimer.inject(ai_response, language)
    disclaimer_shown = final_response != ai_response

    # ---- Update conversation history with assistant response ----
    history.append({"role": "assistant", "content": final_response})
    _sessions.update(session_id, conversation_history=history[-20:])  # keep last 20 turns

    # Collect all warnings/errors
    validation_errors: list[str] = profile_errors[:]
    if lang_warning:
        validation_errors.append(lang_warning)
    if msg_error:
        validation_errors.append(msg_error)

    return jsonify({
        "response": final_response,
        "session_id": session_id,
        "disclaimer_shown": disclaimer_shown,
        "validation_errors": validation_errors,
        "scheme_context": {
            "scheme_id": scheme_context["scheme_id"],
            "scheme_name": scheme_context["scheme_name"],
            "apply_portal_url": scheme_context["apply_portal_url"],
        } if scheme_context else None,
        "eligibility_result": eligibility_result_dict,
    })


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

_ELIGIBILITY_KEYWORDS = frozenset({
    "eligible", "eligibility", "qualify", "qualification",
    "can i", "am i", "do i qualify", "will i get",
    "पात्र", "पात्रता",   # Hindi
    "पात्र", "पात्रता",   # Marathi
    "ಅರ್ಹ", "ಅರ್ಹತೆ",     # Kannada
    "પાત્ર", "પાત્રતા",   # Gujarati
})


def _is_eligibility_query(message: str) -> bool:
    """Return True if the message appears to be asking about eligibility."""
    lower = message.lower()
    return any(kw in lower for kw in _ELIGIBILITY_KEYWORDS)


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    debug = os.environ.get("FLASK_DEBUG", "1") == "1"
    print(f"\n🏛️  Citizen Services Assistant")
    print(f"   Running on http://127.0.0.1:{port}")
    print(f"   Open your browser and go to: http://127.0.0.1:{port}\n")
    app.run(host="127.0.0.1", port=port, debug=debug)
