"""
mcp_server.py
Local MCP (Model Context Protocol) server for the Citizen Services Assistant.

Exposes three tools to IBM Bob:
  - search_schemes   : filter schemes by keyword, category, and/or state
  - get_scheme_details : return the full record for one scheme by ID
  - list_categories  : return the distinct list of scheme categories

Run as a subprocess registered in Bob's MCP configuration.
IBM Bob will call these tools automatically during conversations when it
needs to look up real scheme data instead of guessing.

Usage (for registration in Bob MCP config):
  command: python
  args: ["backend/mcp_server.py"]
  cwd: <project root>
"""

from __future__ import annotations

import json
import os
import sys
import logging
from typing import Any

# ---------------------------------------------------------------------------
# Minimal stdio MCP protocol implementation
# (No external MCP SDK dependency — keeps the project beginner-friendly)
# ---------------------------------------------------------------------------

logging.basicConfig(level=logging.WARNING, stream=sys.stderr)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Scheme data loader
# ---------------------------------------------------------------------------

def _load_schemes() -> list[dict[str, Any]]:
    """Load and cache the schemes from the JSON data file."""
    data_path = os.path.join(
        os.path.dirname(__file__), "..", "data", "schemes.json"
    )
    with open(data_path, encoding="utf-8") as f:
        raw = json.load(f)
    return raw["schemes"]


_SCHEMES: list[dict[str, Any]] = _load_schemes()


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------

def search_schemes(
    keyword: str = "",
    category: str = "",
    state: str = "",
) -> list[dict[str, Any]]:
    """
    Search schemes by keyword, category, and/or state.

    Returns a list of scheme summaries (not full records) to avoid
    sending unnecessary data to Bob's context window.

    Args:
        keyword:  Free-text search against scheme name and descriptions.
        category: Filter by scheme category (case-insensitive).
        state:    Filter by applicable state. Use "ALL" or empty for any.

    Returns:
        List of summary dicts with keys: scheme_id, scheme_name,
        department, category, description_simple.
    """
    results: list[dict[str, Any]] = []

    keyword_lower = keyword.strip().lower()
    category_lower = category.strip().lower()
    state_lower = state.strip().lower()

    for scheme in _SCHEMES:
        # ---- Category filter ----
        if category_lower and scheme["category"].lower() != category_lower:
            continue

        # ---- State filter ----
        if state_lower and state_lower not in ("all", ""):
            applicable = [s.lower() for s in scheme["applicable_states"]]
            if "all" not in applicable and state_lower not in applicable:
                continue

        # ---- Keyword filter (name + descriptions) ----
        if keyword_lower:
            searchable = " ".join([
                scheme["scheme_name"],
                scheme["description_simple"],
                scheme["description_official"],
                scheme["category"],
                scheme["department"],
            ]).lower()
            if keyword_lower not in searchable:
                continue

        results.append({
            "scheme_id": scheme["scheme_id"],
            "scheme_name": scheme["scheme_name"],
            "department": scheme["department"],
            "category": scheme["category"],
            "description_simple": scheme["description_simple"],
            "apply_portal_url": scheme["apply_portal_url"],
        })

    return results


def get_scheme_details(scheme_id: str) -> dict[str, Any] | None:
    """
    Return the full record for a scheme by its scheme_id.

    Args:
        scheme_id: The unique slug for the scheme (e.g. "pm-kisan").

    Returns:
        The full scheme dict, or None if not found.
    """
    scheme_id_lower = scheme_id.strip().lower()
    for scheme in _SCHEMES:
        if scheme["scheme_id"].lower() == scheme_id_lower:
            return scheme
    return None


def list_categories() -> list[str]:
    """
    Return the list of distinct scheme categories available in the dataset.

    Returns:
        Sorted list of category name strings.
    """
    return sorted({scheme["category"] for scheme in _SCHEMES})


# ---------------------------------------------------------------------------
# Minimal JSON-RPC / stdio MCP protocol handler
# ---------------------------------------------------------------------------

TOOLS = {
    "search_schemes": {
        "description": (
            "Search government schemes by keyword, category, and/or state. "
            "Returns a list of matching scheme summaries. Use this when the citizen "
            "asks to discover or find schemes relevant to their situation."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "keyword": {
                    "type": "string",
                    "description": "Free-text search term, e.g. 'farmer', 'health insurance'",
                },
                "category": {
                    "type": "string",
                    "description": (
                        "Scheme category to filter by. One of: Agriculture, Health, "
                        "Housing, Education, Women, SeniorCitizens, Employment, Finance"
                    ),
                },
                "state": {
                    "type": "string",
                    "description": "State name to filter by, or empty for all states",
                },
            },
            "required": [],
        },
    },
    "get_scheme_details": {
        "description": (
            "Retrieve the full details of a specific scheme by its scheme_id. "
            "Use this when you need eligibility rules, required documents, "
            "or application steps for a specific scheme."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "scheme_id": {
                    "type": "string",
                    "description": "The unique scheme identifier slug, e.g. 'pm-kisan'",
                },
            },
            "required": ["scheme_id"],
        },
    },
    "list_categories": {
        "description": (
            "List all available scheme categories in the dataset. "
            "Use this when the citizen wants to browse by category or "
            "when you need to show what types of schemes are available."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
            "required": [],
        },
    },
}


def _make_response(request_id: Any, result: Any) -> dict:
    return {"jsonrpc": "2.0", "id": request_id, "result": result}


def _make_error(request_id: Any, code: int, message: str) -> dict:
    return {
        "jsonrpc": "2.0",
        "id": request_id,
        "error": {"code": code, "message": message},
    }


def _handle_request(request: dict) -> dict:
    """Dispatch a single JSON-RPC request and return a response dict."""
    method = request.get("method", "")
    req_id = request.get("id")
    params = request.get("params", {})

    if method == "initialize":
        return _make_response(req_id, {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {
                "name": "citizen-services-mcp",
                "version": "1.0.0",
            },
        })

    if method == "initialized":
        # Notification — no response needed, return None sentinel
        return None  # type: ignore[return-value]

    if method == "tools/list":
        tools_list = [
            {
                "name": name,
                "description": meta["description"],
                "inputSchema": meta["inputSchema"],
            }
            for name, meta in TOOLS.items()
        ]
        return _make_response(req_id, {"tools": tools_list})

    if method == "tools/call":
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})

        if tool_name == "search_schemes":
            data = search_schemes(
                keyword=arguments.get("keyword", ""),
                category=arguments.get("category", ""),
                state=arguments.get("state", ""),
            )
            return _make_response(req_id, {
                "content": [{"type": "text", "text": json.dumps(data, ensure_ascii=False)}]
            })

        if tool_name == "get_scheme_details":
            scheme_id = arguments.get("scheme_id", "")
            data = get_scheme_details(scheme_id)
            if data is None:
                text = json.dumps({"error": f"No scheme found with id '{scheme_id}'"})
            else:
                text = json.dumps(data, ensure_ascii=False)
            return _make_response(req_id, {
                "content": [{"type": "text", "text": text}]
            })

        if tool_name == "list_categories":
            data = list_categories()
            return _make_response(req_id, {
                "content": [{"type": "text", "text": json.dumps(data)}]
            })

        return _make_error(req_id, -32601, f"Unknown tool: {tool_name}")

    return _make_error(req_id, -32601, f"Method not found: {method}")


def run_stdio_server() -> None:
    """
    Read JSON-RPC messages from stdin, write responses to stdout.
    Each message is a single line of JSON (newline-delimited).
    """
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
        except json.JSONDecodeError as exc:
            error = _make_error(None, -32700, f"Parse error: {exc}")
            sys.stdout.write(json.dumps(error) + "\n")
            sys.stdout.flush()
            continue

        response = _handle_request(request)
        if response is not None:  # None means it was a notification
            sys.stdout.write(json.dumps(response, ensure_ascii=False) + "\n")
            sys.stdout.flush()


if __name__ == "__main__":
    run_stdio_server()
