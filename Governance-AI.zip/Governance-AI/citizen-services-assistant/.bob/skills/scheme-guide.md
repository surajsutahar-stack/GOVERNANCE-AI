---
name: scheme-guide
description: >
  Loads domain knowledge about Indian government scheme categories, typical
  eligibility patterns, common document types, and response templates.
  Activate at the start of any citizen scheme conversation.
---

# Scheme Guide — Domain Knowledge Skill

## Scheme Categories

The following categories are used to organise government schemes:

| Category | What it covers |
|---|---|
| Agriculture | Farming, crop insurance, irrigation, fertiliser subsidies, farmer income support |
| Health | Health insurance, hospital coverage, maternal health, senior health |
| Housing | Rural and urban housing construction assistance |
| Education | Scholarships, skill training, mid-day meal, vocational programmes |
| Women | Women-specific welfare, safety, self-help groups, empowerment |
| SeniorCitizens | Old-age pension, senior health, welfare for elderly |
| Employment | Job guarantee schemes, skill development, entrepreneur loans |
| Finance | Bank account access, micro-finance, insurance for the unbanked |

## Typical Eligibility Rule Patterns

When explaining eligibility, always explain each rule in plain language:

- **Age rule:** "This scheme is for people aged [X] to [Y]."
- **Gender rule:** "This scheme is specifically for [gender]."
- **Occupation rule:** "You must be a [occupation type] to be eligible."
- **Income rule:** "Your annual household income must be below ₹[amount]."
- **Social category rule:** "This scheme is available to [SC/ST/OBC/EWS/General] citizens."
- **State rule:** "This scheme is only available in [state name]."

If a rule could not be checked because the citizen did not provide the required
information, say: "I could not check [rule] because you did not provide [field].
You may want to provide this to get a more complete eligibility assessment."

## Common Document Checklist Patterns

When listing required documents, present them as a numbered checklist.
Common documents across many schemes:
- Aadhaar card (identity proof)
- Ration card (BPL/income status proof)
- Bank passbook (for direct benefit transfer)
- Income certificate (issued by local government)
- Caste/category certificate (for SC/ST/OBC schemes)
- Land ownership documents (for agriculture schemes)
- Age proof (birth certificate or school certificate)
- Residence/domicile certificate

## Application Guidance Template

When explaining how to apply, follow this structure:
1. Who processes the application (department / Common Service Centre / portal)
2. Where to go (online portal URL or offline location)
3. What to take (required documents)
4. Key steps in the application process
5. What happens after you apply (next steps / timeline if known)

## Standard Legal Disclaimer

Include this at the end of every eligibility-related response:

---
⚠️ **IMPORTANT DISCLAIMER:** This is AI-generated guidance for informational
purposes only. It is NOT an official government decision and does NOT guarantee
that you will receive this benefit. Please verify eligibility and apply through
the official government portal or your nearest Common Service Centre (CSC).
---

## Multilingual Disclaimer Texts

**Hindi (hi):**
⚠️ **महत्वपूर्ण सूचना:** यह केवल सूचनात्मक उद्देश्यों के लिए AI-जनित मार्गदर्शन है।
यह कोई आधिकारिक सरकारी निर्णय नहीं है। कृपया आधिकारिक सरकारी पोर्टल या
निकटतम जन सेवा केंद्र (CSC) पर पात्रता सत्यापित करें।

**Marathi (mr):**
⚠️ **महत्त्वाची सूचना:** हे केवल माहितीच्या उद्देशाने AI-जनित मार्गदर्शन आहे.
हा कोणताही अधिकृत सरकारी निर्णय नाही. कृपया अधिकृत सरकारी पोर्टलवर किंवा
जवळच्या जन सेवा केंद्रावर (CSC) पात्रता तपासा.

**Gujarati (gu):**
⚠️ **મહત્વની નોંધ:** આ માત્ર માહિતી માટે AI-જનિત માર્ગદર્શન છે.
આ કોઈ સત્તાવાર સરકારી નિર્ણય નથી. કૃપા કરીને સત્તાવાર સરકારી પોર્ટલ અથવા
નજીકના જન સેવા કેન્દ્ર (CSC) પર પાત્રતા ચકાસો.

**Kannada (kn):**
⚠️ **ಮುಖ್ಯ ಸೂಚನೆ:** ಇದು ಕೇವಲ ಮಾಹಿತಿ ಉದ್ದೇಶಗಳಿಗಾಗಿ AI-ಜನಿತ ಮಾರ್ಗದರ್ಶನ.
ಇದು ಯಾವುದೇ ಅಧಿಕೃತ ಸರ್ಕಾರದ ನಿರ್ಧಾರ ಅಲ್ಲ. ದಯವಿಟ್ಟು ಅಧಿಕೃತ ಸರ್ಕಾರಿ ಪೋರ್ಟಲ್ ಅಥವಾ
ಹತ್ತಿರದ ಜನ ಸೇವಾ ಕೇಂದ್ರ (CSC) ದಲ್ಲಿ ಅರ್ಹತೆಯನ್ನು ಪರಿಶೀಲಿಸಿ.
