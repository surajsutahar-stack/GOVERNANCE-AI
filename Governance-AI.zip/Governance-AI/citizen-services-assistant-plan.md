# Citizen Services Assistant — Implementation Plan

## Overview

Build a beginner-friendly, IBM Bob-powered web application that helps citizens discover
government schemes, check basic eligibility, understand required documents, and learn
how to apply — all through a simple chat interface that works in English and four
regional languages (Hindi, Marathi, Gujarati, Kannada).

### Scope

- A single-page web chat UI (HTML + JavaScript)
- A lightweight Python (Flask) backend server
- A local JSON scheme data file (10–15 central government schemes)
- A custom IBM Bob mode, rules, and skill to govern the AI's behaviour
- A local MCP server that bridges IBM Bob to the JSON data file
- Deterministic eligibility matching in Python (AI explains the result, not guesses it)
- Session-only user profile (nothing persisted to disk or a database)
- No authentication, no database, no paid external APIs beyond IBM Bob / watsonx.ai

### Out of Scope for MVP

- Mobile app
- Live government API integration
- User accounts or saved history
- Voice input
- Automated scheme data updates
- Production deployment / cloud hosting

### Design Principles

1. Keep every file simple enough for a junior developer to read in one sitting.
2. IBM Bob handles all natural-language reasoning; Python handles deterministic logic.
3. Scheme data lives in one editable JSON file — adding a scheme never requires a code change.
4. Legal guardrails are enforced by Bob rules, not by trusting the LLM to "remember".
5. Privacy by default: no PII is ever written to disk.

---

## Technology Stack

| Layer | Technology | Why |
|---|---|---|
| Frontend | HTML5 + vanilla JavaScript | No framework needed for a chat UI; beginner-readable |
| Backend | Python 3 + Flask | Minimal boilerplate; easy for beginners |
| AI / LLM | IBM Bob (watsonx.ai model) via Bob's API | Stays fully inside IBM ecosystem |
| Bob Configuration | Custom mode, rules, skills (.bob/ folder) | Controls Bob persona and guardrails |
| Scheme Data | JSON file | Human-readable, zero-dependency data store |
| MCP Server | Python stdio MCP server | Exposes scheme data tools to Bob |
| Translation | IBM Bob LLM (at query time) | No separate translation API needed |
| Session State | Python in-memory dict (per request context) | Simple; no session database |

---

## System Architecture

```
Browser (HTML/JS Chat Page)
        |
        | HTTP POST /chat
        v
Flask Backend (app.py)
        |
        |-- 1. Parse user message + profile inputs
        |-- 2. Run eligibility check (Python rule matcher)
        |-- 3. Build prompt with scheme context
        |
        | IBM Bob API call (watsonx.ai)
        v
IBM Bob LLM
        |  governed by:
        |    - Custom Mode: citizen-guide
        |    - Rules: citizen-guide-rules.md
        |    - Skill: scheme-guide.md
        |
        | MCP tool call (if scheme lookup needed)
        v
Local MCP Server (mcp_server.py)
        |
        v
schemes.json  <-- single source of truth for all scheme data
        |
        v
Flask Backend receives Bob's response
        |
        | Inject disclaimer if response contains eligibility guidance
        v
Browser displays formatted response
```

---

## Folder / Project Structure

```
citizen-services-assistant/
|
|-- .bob/
|   |-- custom_modes.yaml          # Defines citizen-guide mode
|   |-- rules/
|   |   |-- citizen-guide-rules.md # Always-on guardrails for the assistant
|   |-- skills/
|       |-- scheme-guide.md        # Domain knowledge skill loaded on demand
|
|-- data/
|   |-- schemes.json               # All 10-15 scheme records
|
|-- backend/
|   |-- app.py                     # Flask server — main entry point
|   |-- eligibility.py             # Rule-based eligibility matching logic
|   |-- session.py                 # In-memory session context helpers
|   |-- disclaimer.py              # Appends legal disclaimer text
|   |-- mcp_server.py              # Local MCP server exposing scheme data tools
|
|-- frontend/
|   |-- index.html                 # Chat page
|   |-- style.css                  # Simple, accessible styling
|   |-- chat.js                    # Handles user input, API calls, UI updates
|
|-- tests/
|   |-- test_eligibility.py        # Unit tests for eligibility matching
|   |-- test_schemes.py            # Validates that schemes.json is well-formed
|
|-- README.md                      # Setup and run instructions
|-- requirements.txt               # Python dependencies (flask, requests)
```

**Why this structure?**
Every concern lives in its own small file. A beginner can open any file and understand
its single purpose without needing to trace through the rest of the codebase.

---

## Data Model

### Scheme Record (schemes.json)

Each entry in the JSON array represents one government scheme.

```
Field                  Type        Description
------                 -----       -----------
scheme_id              string      Short unique slug, e.g. "pm-kisan"
scheme_name            string      Official English name
department             string      Issuing ministry / department
category               string      One of: Agriculture, Health, Housing, Education,
                                   Women, SeniorCitizens, Employment, Finance
applicable_states      array       ["ALL"] for central schemes or list of state names
description_simple     string      Plain-language summary (max 3 sentences)
description_official   string      Official description (verbatim or close paraphrase)
eligibility_rules      object      See Eligibility Rules sub-model below
required_documents     array       List of document name strings
how_to_apply           string      Step-by-step plain-language guidance
apply_portal_url       string      Official URL
source_url             string      URL to the scheme's official page
last_verified_date     string      ISO date — when data was last checked
```

#### Eligibility Rules Sub-Model

```
Field                  Type        Notes
------                 -----       -----
min_age                integer     Null means no lower limit
max_age                integer     Null means no upper limit
gender                 string      "Any", "Male", "Female", "Transgender"
occupation             array       List of matching occupations; ["ANY"] = no restriction
income_max_annual_inr  integer     Null means no income limit
social_category        array       ["ANY"] or subset of ["General","SC","ST","OBC","EWS"]
state_required         string      "ALL" or specific state name
other_conditions       string      Human-readable text for complex rules not captured above
```

### User Profile (session-only — never written to disk)

```
Field               Type       Source
-----               -----      ------
age                 integer    User input
gender              string     User input
occupation          string     User input
annual_income_inr   integer    User input (approximate)
state               string     User input (dropdown)
social_category     string     User input
preferred_language  string     Language selector (default: "en")
```

---

## IBM Bob Configuration

### Custom Mode: citizen-guide

**File:** `.bob/custom_modes.yaml`

The mode gives Bob the "Citizen Services Guide" persona. Key properties:

- **Role definition:** You are a helpful, empathetic government scheme guide who explains
  public schemes in simple language, checks basic eligibility, and guides citizens on
  how to apply. You only discuss government schemes.
- **whenToUse:** Active for all citizen assistant conversations.
- **Tool access:** read, mcp, skill tools only. No write or execute tools permitted.
- **Custom instructions:** Always respond in the user's selected language. Never guarantee
  eligibility. Never discuss topics unrelated to government schemes.

### Bob Rules: citizen-guide-rules.md

**File:** `.bob/rules/citizen-guide-rules.md`

Rules are always active regardless of mode. This file enforces:

1. Every response that includes eligibility guidance MUST end with the standard disclaimer.
2. Never invent scheme names, rules, or documents. Only cite schemes from the MCP data.
3. Always use simple language (avoid bureaucratic jargon).
4. If a question is outside the scope of government schemes, politely redirect.
5. Never store, repeat, or log any personal information shared by the user.
6. If scheme data is unavailable, say so clearly — do not guess.

### Bob Skill: scheme-guide.md

**File:** `.bob/skills/scheme-guide.md`

Loaded on demand when the conversation involves scheme discovery or eligibility.
Contains:

- Explanation of scheme categories and what each covers
- Typical eligibility rule patterns (age bands, income thresholds, category requirements)
- Document checklist patterns (Aadhaar, income certificate, caste certificate, etc.)
- Guidance on how to frame eligibility explanations for citizens
- The standard legal disclaimer text to include in responses

### MCP Server: mcp_server.py

Exposes three tools to Bob:

| Tool Name | Input | Output |
|---|---|---|
| `search_schemes` | keyword, category (optional), state (optional) | Array of matching scheme summaries |
| `get_scheme_details` | scheme_id | Full scheme record |
| `list_categories` | none | Array of available scheme categories |

Bob calls these tools when it needs real scheme data to answer a question.
This prevents hallucination because Bob fetches facts rather than inventing them.

---

## Main Modules

### 1. Flask Backend — app.py

**Responsibility:** Entry point. Receives HTTP POST from the browser, orchestrates the
request, calls IBM Bob API, returns the response.

**Key endpoints:**

| Endpoint | Method | Purpose |
|---|---|---|
| `/` | GET | Serves the chat HTML page |
| `/chat` | POST | Accepts user message + profile; returns AI response |
| `/schemes/categories` | GET | Returns available scheme categories for the UI dropdown |

**Request flow for /chat:**
1. Parse incoming JSON: `{message, user_profile, language, session_id}`
2. Call `eligibility.py` if the message is an eligibility query and profile is present
3. Build a context object: `{scheme_data, eligibility_result, user_language}`
4. Call IBM Bob API with the context-enriched prompt
5. If the response contains eligibility guidance, call `disclaimer.py` to append the disclaimer
6. Return JSON: `{response_text, schemes_referenced, disclaimer_shown}`

### 2. Eligibility Checker — eligibility.py

**Responsibility:** Deterministic rule-based matching. Compares user profile against a
scheme's `eligibility_rules`. Returns a structured result that Bob explains in natural language.

**Why separate from Bob?**
Eligibility matching should be predictable, auditable, and repeatable. If the LLM did
the matching, results could vary between runs. Python code always produces the same
result for the same inputs.

**Output structure per scheme:**

```
{
  "scheme_id": "pm-kisan",
  "match_status": "likely_eligible" | "may_not_qualify" | "insufficient_data",
  "rules_checked": [
    {"rule": "age", "required": "18-70", "user_value": "35", "passed": true},
    {"rule": "occupation", "required": ["Farmer"], "user_value": "Farmer", "passed": true},
    ...
  ],
  "missing_fields": ["social_category"],
  "notes": "Income rule could not be checked — income not provided"
}
```

### 3. Session Manager — session.py

**Responsibility:** Maintains lightweight in-memory context for the current conversation.
Stores: current scheme being discussed, user profile inputs, language preference.

**Design decision:** Use a Python dict keyed by a random session ID generated at page load.
Sessions are cleared after 30 minutes of inactivity. Nothing is ever written to disk.

### 4. Disclaimer Injector — disclaimer.py

**Responsibility:** Detects whether a response contains eligibility guidance (by checking
for trigger phrases) and appends the standard disclaimer if so.

**Why a separate module?**
Bob's rules ask it to include a disclaimer, but as an extra safety layer, the backend
independently injects the disclaimer for any response that discusses eligibility. Defence
in depth — two independent guardrails are better than one.

### 5. MCP Server — mcp_server.py

**Responsibility:** Runs as a local stdio MCP process. Reads `schemes.json` on startup
and exposes the three scheme data tools to IBM Bob.

**Why MCP instead of embedding scheme data in the prompt?**
Putting all 10–15 schemes in every prompt wastes context window tokens. With MCP, Bob
only fetches the scheme(s) relevant to the current question.

### 6. Chat Frontend — index.html + chat.js

**Responsibility:** Renders the conversation, collects user profile inputs, handles
language selection, and calls the Flask `/chat` endpoint.

**Key UI components:**

- Language selector (dropdown: English, Hindi, Marathi, Gujarati, Kannada)
- Profile panel (collapsible form: age, gender, occupation, income, state, social category)
- Chat message list (user bubbles + assistant bubbles)
- Scheme category filter (optional quick-filter buttons)
- Disclaimer banner (always visible at page bottom)
- "This is AI guidance only" label on every eligibility response

---

## Workflows

### Workflow 1 — Scheme Discovery

Goal: User wants to find schemes relevant to their situation.

```
1. User types: "What schemes are available for farmers?"
2. chat.js POSTs {message, language, profile} to /chat
3. app.py builds a prompt including the user's message and language
4. Bob receives the prompt in citizen-guide mode
5. Bob calls MCP tool: search_schemes(category="Agriculture")
6. MCP server queries schemes.json, returns matching scheme summaries
7. Bob formats a plain-language list of schemes in the user's language
8. app.py returns the response to the browser
9. chat.js displays the formatted list with scheme cards
```

### Workflow 2 — Eligibility Guidance

Goal: User wants to know if they qualify for a specific scheme.

```
1. User has filled in profile panel (age, occupation, income, state, category)
2. User types: "Am I eligible for PM-KISAN?"
3. app.py calls eligibility.py with (user_profile, scheme_id="pm-kisan")
4. eligibility.py loads pm-kisan rules from schemes.json
5. eligibility.py runs rule checks, produces structured result
6. app.py calls Bob API with prompt containing:
   - User's question
   - The eligibility result object
   - Instruction: "Explain this result in plain language in [language]"
7. Bob generates a conversational explanation (it does NOT re-run the logic)
8. disclaimer.py appends the legal disclaimer
9. Response is returned with an "AI Guidance Only" label in the UI
```

### Workflow 3 — Application Support

Goal: User wants to know what documents to gather and how to apply.

```
1. User types: "How do I apply for Ayushman Bharat? What documents do I need?"
2. app.py builds prompt, Bob calls MCP: get_scheme_details("ayushman-bharat")
3. MCP returns full scheme record including required_documents and how_to_apply
4. Bob formats the document list and application steps in the user's language
5. Response includes the official apply_portal_url as a clickable link
6. UI displays documents as a numbered checklist
```

### Workflow 4 — Multilingual Response

Goal: User selects a regional language; all subsequent responses should be in that language.

```
1. User selects "Marathi" from language dropdown
2. chat.js stores preferred_language = "mr" in session state
3. Every subsequent /chat POST includes {language: "mr"}
4. app.py adds to the prompt: "Respond entirely in Marathi. Keep the language simple."
5. Bob generates the full response in Marathi
6. If scheme names or official terms have no Marathi equivalent, keep them in English
   and add a brief Marathi explanation
7. Disclaimer is also appended in Marathi (pre-written in disclaimer.py)
```

### Workflow 5 — Follow-Up Questions

Goal: User asks a follow-up about the scheme just discussed.

```
1. session.py stores the last scheme_id discussed in the session context
2. User types: "What is the income limit for that scheme?"
3. app.py retrieves scheme_id from session context
4. Prompt is enriched with the scheme context from the previous turn
5. Bob answers the follow-up without the user needing to name the scheme again
```

---

## Input Validation Approach

Validation runs in two places:

**Frontend (chat.js):**
- Free-text message: required, max 500 chars, stripped of leading/trailing whitespace
- Age: positive integer 1–120 (if provided)
- Annual income: non-negative integer (if provided)
- State: must match a value from the predefined state list
- Language: must match one of the five supported language codes

**Backend (app.py):**
- Re-validate all profile fields on arrival (never trust frontend-only validation)
- Sanitize text inputs: strip HTML tags, truncate to max length
- If age or income is outside valid range, reject with a 400 error and friendly message
- If required fields for eligibility check are missing, eligibility.py returns
  `match_status: "insufficient_data"` and lists the missing fields

---

## Error Handling Approach

| Scenario | Behaviour |
|---|---|
| IBM Bob API is unavailable | Return a friendly message: "The AI assistant is temporarily unavailable. Please try again shortly." |
| schemes.json cannot be read | Return: "Scheme data is temporarily unavailable. Please visit india.gov.in directly." |
| No schemes match the search | Return: "No matching schemes found for your query. Try a different keyword or category." |
| User asks about a scheme not in the database | Bob acknowledges the gap and suggests checking the official portal — it does not invent data |
| Eligibility check has missing profile fields | Return the result with `match_status: "insufficient_data"` and a list of missing fields |
| Unsupported language code | Default to English and display a note: "This language is not yet supported. Showing English." |
| User input is empty or only whitespace | Display: "Please type a question to get started." |
| Session has expired (30 min inactivity) | Reset session silently and display: "Your session has been reset. Please re-enter your details if needed." |

---

## Privacy and Security Approach

1. **No PII stored to disk.** User profile data exists only in the in-memory session dict.
2. **Sessions cleared after inactivity.** 30-minute TTL on all session data.
3. **No user accounts or login.** Fully anonymous — no email, phone, or name collected.
4. **Input sanitization.** All text inputs are sanitized before being passed to the LLM prompt.
5. **No analytics scripts.** The frontend does not include third-party tracking libraries.
6. **HTTPS recommended.** README instructs deployers to use HTTPS even for local demos.
7. **Prompt injection mitigation.** Backend wraps user input in a structured prompt that
   clearly separates user text from system instructions. User input is never placed
   directly into the system instruction block.
8. **Transparency notice.** The chat page displays a visible notice: "Your information is
   only used within this session and is never saved."

---

## AI Safety and Responsible AI Considerations

| Concern | Mitigation |
|---|---|
| Hallucinated scheme names | Bob fetches schemes via MCP — it cannot invent a scheme that is not in the JSON |
| Incorrect eligibility decisions | Eligibility is determined by Python rule matching, not by the LLM |
| Missing disclaimer | Two independent guardrails: Bob rules + disclaimer.py in the backend |
| Off-topic harmful content | Bob rules redirect any non-scheme question back to the assistant's purpose |
| Language of authority | All responses use hedged language: "you may be eligible", "this scheme may apply" |
| Outdated scheme data | last_verified_date is shown on each scheme card; users are reminded to verify |
| LLM bias in eligibility explanations | Explanations are derived from the deterministic rule result, not from LLM reasoning |

---

## Handling Official Government Information

1. **Source attribution:** Every scheme card shows the department name and a link to the
   official source URL stored in schemes.json.
2. **Verbatim official description preserved:** `description_official` stores the original
   language of the scheme. `description_simple` is the simplified version shown to citizens.
   Both are available so users can always see the official wording.
3. **Portal links:** `apply_portal_url` links directly to the official application portal.
   These links are displayed as "Apply on the official portal →" buttons.
4. **No paraphrasing of legal rules:** Eligibility rules in `eligibility_rules` are stored
   as structured data derived from official sources — they are not paraphrased by the AI.
5. **Freshness warning:** If `last_verified_date` is more than 6 months old, the scheme
   card shows a yellow warning: "This information was last verified on [date]. Please
   confirm current details on the official portal."

---

## Handling Uncertain or Missing Information

| Situation | Response Strategy |
|---|---|
| Scheme not in database | "I don't have information about that scheme. You can find it at [india.gov.in/schemes]." |
| User asks a question the data cannot answer | "I can't answer that from the available data. Please check [source_url] for details." |
| Eligibility cannot be determined (missing user fields) | List the missing fields and offer to check eligibility once the user provides them |
| Eligibility rules say "other_conditions" (complex rules) | Surface the `other_conditions` text and recommend verifying with the relevant department |
| Scheme has state-specific variations not in the data | Note that state-level variations may exist and recommend checking with the state department |
| Translation uncertainty | Add a note: "This is an AI translation. Please refer to the official Hindi/English version for accuracy." |

---

## Testing Strategy

### Unit Tests — test_eligibility.py

Test the eligibility matcher in isolation using sample user profiles and scheme records.
Cover: age boundary conditions, income boundary, category matching, multi-rule combinations,
missing fields, all-ANY rule schemes, state-restricted schemes.

### Data Validation Tests — test_schemes.py

Load schemes.json and verify: all required fields are present, URLs are well-formed,
eligibility rule types match the expected types, no duplicate scheme_ids,
categories are drawn from the allowed list.

### Manual Integration Tests (checklist in README)

- [ ] Ask "What schemes are available for farmers?" — verify scheme list is returned
- [ ] Fill profile and ask about PM-KISAN eligibility — verify correct match + disclaimer
- [ ] Ask for documents needed for Ayushman Bharat — verify correct document list
- [ ] Switch language to Hindi — verify full response is in Hindi
- [ ] Ask a follow-up question about a scheme — verify context is maintained
- [ ] Ask about a scheme not in the database — verify graceful "not found" response
- [ ] Ask an off-topic question — verify Bob redirects back to scheme topics
- [ ] Submit an empty message — verify frontend validation blocks the request

### Bob Configuration Tests

- Verify the disclaimer appears on every eligibility response
- Verify Bob does not invent scheme names not in schemes.json
- Verify Bob responds in the correct language when language preference is set

---

## Example User Journeys

### Journey 1 — Farmer in Maharashtra

> Ravi, 42, a farmer from Pune, Maharashtra, wants to know what government help is available.

1. Ravi opens the chat page and selects Marathi as his language.
2. He types (in Marathi): "शेतकऱ्यांसाठी कोणत्या योजना आहेत?" (What schemes are there for farmers?)
3. The assistant lists PM-KISAN, PM Fasal Bima Yojana, and Kisan Credit Card in Marathi.
4. Ravi fills the profile: age 42, male, farmer, income ₹1.2 lakh/year, Maharashtra, General.
5. He asks: "PM-KISAN साठी मी पात्र आहे का?" (Am I eligible for PM-KISAN?)
6. The eligibility checker runs: age ✅, occupation ✅, income ✅, state ✅ → Likely Eligible.
7. Bob explains the result in Marathi with the legal disclaimer appended.
8. Ravi asks: "कोणती कागदपत्रे लागतात?" (What documents are needed?)
9. Bob lists: Aadhaar card, land ownership documents, bank passbook, in Marathi.

### Journey 2 — Student in Gujarat

> Priya, 19, a student from Surat, Gujarat, looking for scholarship schemes.

1. Priya selects Gujarati as her language.
2. She types: "Students ne koi scholarship scheme meli?" (Is there a scholarship scheme for students?)
3. The assistant returns: National Scholarship Portal schemes, PM Scholarship.
4. Priya fills profile: age 19, female, student, income (family) ₹3 lakh/year, Gujarat, OBC.
5. She asks about eligibility for PM Scholarship.
6. Eligibility: age ✅, gender ✅, category ✅, income ✅ → Likely Eligible.
7. Bob explains in Gujarati with disclaimer and a link to the application portal.

### Journey 3 — Senior Citizen in Bangalore

> Anwar, 67, retired, Bangalore, Karnataka, seeking pension scheme information.

1. Anwar selects Kannada.
2. He asks (in English, as he is comfortable): "What pension schemes are available for retired people?"
3. Bob responds in Kannada (as selected): lists IGNOAPS, Atal Pension Yojana.
4. Anwar fills profile, asks about IGNOAPS eligibility.
5. Eligibility: age ✅ (must be 60+), income must be below BPL → match_status: "insufficient_data" (BPL status not captured).
6. Bob explains in Kannada: "I need your BPL card status to check this fully. The scheme requires
   the applicant to be Below Poverty Line."
7. Anwar does not have that information — Bob recommends visiting the nearest Common Service Centre.

---

## Sample Government Scheme Records (for schemes.json)

| scheme_id | scheme_name | category | Key Eligibility |
|---|---|---|---|
| pm-kisan | PM Kisan Samman Nidhi | Agriculture | Farmer, any income, 18-70 |
| pm-fasal-bima | PM Fasal Bima Yojana | Agriculture | Farmer, enrolled in state notification |
| ayushman-bharat | Ayushman Bharat PM-JAY | Health | SECC-listed family or below poverty line |
| pmay-gramin | PMAY Gramin | Housing | Rural, no pucca house, income < 6 lakh |
| pmay-urban | PMAY Urban | Housing | Urban, no pucca house, income < 18 lakh |
| national-scholarship | National Scholarship Portal | Education | Student, income < 8 lakh, various categories |
| pm-scholarship-csb | PM Scholarship (CSB/RPF) | Education | Wards of ex-servicemen / police |
| beti-bachao | Beti Bachao Beti Padhao | Women | Girl child family, state-specific |
| ignoaps | IGNOAPS Old Age Pension | SeniorCitizens | Age 60+, BPL, any state |
| pm-mudra | PM Mudra Yojana | Employment/Finance | Non-farm small business, 18-65 |
| skill-india | Skill India / PMKVY | Employment | 15-45, seeking vocational training |
| mgnregs | MGNREGS | Employment | Rural household, adult member, 100 days |
| jan-dhan | PM Jan Dhan Yojana | Finance | Any Indian resident without a bank account |
| ujjwala | PM Ujjwala Yojana | Women | BPL household, woman applicant |
| kisan-credit-card | Kisan Credit Card | Agriculture | Farmer / fisherman / animal husbandry |

---

## Sub-Tasks

---

### Sub-Task 1 — Project Scaffold and Bob Configuration

**Intent:** Create the folder structure and all IBM Bob configuration files. This establishes
the project skeleton and gives Bob its "Citizen Guide" persona before any application code is written.

**Expected Outcomes:**
- `.bob/custom_modes.yaml` created with the citizen-guide mode
- `.bob/rules/citizen-guide-rules.md` created with all guardrails
- `.bob/skills/scheme-guide.md` created with domain knowledge
- All directories from the project structure exist
- `requirements.txt` and `README.md` created

**Todo List:**
- [ ] Create the full directory structure as defined in the Folder Structure section
- [ ] Write `.bob/custom_modes.yaml` with the citizen-guide custom mode definition
- [ ] Write `.bob/rules/citizen-guide-rules.md` with all seven guardrail rules
- [ ] Write `.bob/skills/scheme-guide.md` with scheme category knowledge and disclaimer text
- [ ] Create `requirements.txt` listing flask and requests
- [ ] Create `README.md` with setup and run instructions

**Status:** [ ] pending

---

### Sub-Task 2 — Scheme Data File

**Intent:** Build the `schemes.json` file with all 15 sample scheme records matching
the data model exactly. This is the single source of truth for the entire application.

**Expected Outcomes:**
- `data/schemes.json` contains all 15 schemes listed in the Sample Scheme Records section
- Every scheme has all required fields including `eligibility_rules`, `required_documents`,
  `how_to_apply`, and `apply_portal_url`
- `test_schemes.py` passes validation on the file

**Todo List:**
- [ ] Create `data/schemes.json` with all 15 scheme records per the data model
- [ ] Ensure eligibility_rules for each scheme are structured (not free-text only)
- [ ] Populate required_documents and how_to_apply for each scheme
- [ ] Write `tests/test_schemes.py` to validate the JSON structure
- [ ] Run test_schemes.py and confirm it passes

**Status:** [ ] pending

---

### Sub-Task 3 — MCP Server

**Intent:** Build the local MCP server that exposes scheme data to IBM Bob via the three
defined tools. Bob uses these tools instead of hallucinating scheme facts.

**Expected Outcomes:**
- `backend/mcp_server.py` runs as a stdio MCP process
- Three tools exposed: `search_schemes`, `get_scheme_details`, `list_categories`
- MCP server reads and caches `schemes.json` on startup
- Bob can call the tools from within a conversation and receive correct scheme data
- MCP server is registered in `.bob/` configuration

**Todo List:**
- [ ] Write `backend/mcp_server.py` implementing the three tools using Python MCP SDK
- [ ] Implement `search_schemes` with keyword, category, and state filters
- [ ] Implement `get_scheme_details` returning a full scheme record by ID
- [ ] Implement `list_categories` returning the distinct list of categories from the data
- [ ] Register the MCP server in the Bob MCP configuration
- [ ] Test each tool manually via Bob conversation

**Status:** [ ] pending

---

### Sub-Task 4 — Eligibility Checker and Disclaimer Modules

**Intent:** Build the deterministic eligibility matching logic in Python and the disclaimer
injector. These are the two backend safety components that ensure reliable, guarded outputs.

**Expected Outcomes:**
- `backend/eligibility.py` correctly matches a user profile against any scheme's rules
- Returns structured result with match_status, rules_checked, and missing_fields
- `backend/disclaimer.py` detects eligibility-related responses and appends the disclaimer
- `tests/test_eligibility.py` covers all boundary cases and passes

**Todo List:**
- [ ] Write `backend/eligibility.py` with the `check_eligibility(user_profile, scheme)` function
- [ ] Handle each rule type: age range, gender, occupation list, income cap, social category, state
- [ ] Return "insufficient_data" with missing_fields list when required profile data is absent
- [ ] Write `backend/disclaimer.py` with disclaimer text in all five supported languages
- [ ] Write `tests/test_eligibility.py` covering at least 10 test cases
- [ ] Run tests and confirm all pass

**Status:** [ ] pending

---

### Sub-Task 5 — Flask Backend

**Intent:** Build the Flask server that ties all backend modules together and serves as
the API layer between the frontend and IBM Bob.

**Expected Outcomes:**
- `backend/app.py` runs and serves the frontend HTML file
- POST /chat accepts a message + profile, calls Bob API, returns a response
- GET /schemes/categories returns the list of categories
- Session management works correctly (context maintained within a session)
- All error handling scenarios return appropriate messages

**Todo List:**
- [ ] Write `backend/app.py` with the three endpoints defined in the Modules section
- [ ] Implement the /chat request flow: validate inputs, run eligibility if applicable,
  build enriched prompt, call Bob API, inject disclaimer, return response
- [ ] Write `backend/session.py` for in-memory session context (TTL 30 min)
- [ ] Integrate eligibility.py and disclaimer.py into the /chat flow
- [ ] Add input validation and sanitization for all incoming fields
- [ ] Add all error handling cases from the Error Handling section
- [ ] Test all endpoints manually with a REST client

**Status:** [ ] pending

---

### Sub-Task 6 — Chat Frontend

**Intent:** Build the single-page web chat interface that citizens use to interact with
the assistant. Must be accessible, simple, and clearly communicate the AI guidance disclaimer.

**Expected Outcomes:**
- `frontend/index.html` opens in a browser and shows the chat interface
- Language selector changes the language of all subsequent responses
- Profile panel collects and stores user inputs for the session
- Chat messages display correctly with role indicators (user vs assistant)
- Eligibility responses are visually labelled "AI Guidance Only"
- The legal disclaimer is permanently visible at the bottom
- All frontend validation rules are enforced before submission

**Todo List:**
- [ ] Write `frontend/index.html` with: language selector, profile panel, chat message area,
  scheme category quick-filter buttons, disclaimer banner
- [ ] Write `frontend/style.css` with accessible, high-contrast, mobile-friendly layout
- [ ] Write `frontend/chat.js` with: message sending, profile data collection,
  session ID generation, API call to /chat, response rendering
- [ ] Add the "AI Guidance Only" badge to eligibility responses in chat.js
- [ ] Add all frontend input validation rules from the Validation section
- [ ] Test the full UI flow manually end-to-end

**Status:** [ ] pending

---

### Sub-Task 7 — Integration Testing and README

**Intent:** Validate the complete end-to-end system using the manual test checklist
and ensure the README gives a beginner clear setup instructions.

**Expected Outcomes:**
- All 8 manual integration test checklist items pass
- Bob configuration tests pass (disclaimer always shown, no hallucinated schemes, language correct)
- README contains step-by-step setup, run instructions, and troubleshooting tips
- A beginner developer can follow the README from a fresh clone to a running demo

**Todo List:**
- [ ] Run through the full manual integration test checklist from the Testing section
- [ ] Run test_eligibility.py and test_schemes.py and confirm both pass
- [ ] Fix any issues found during integration testing
- [ ] Update README with final setup instructions, environment variables needed, and
  instructions for running the MCP server alongside the Flask app
- [ ] Add a brief "How it works" section to the README explaining the Bob + MCP architecture

**Status:** [ ] pending

---

## Future Improvements

These are explicitly out of scope for the MVP but are logical next steps:

| Improvement | Why it would help |
|---|---|
| Live scheme data from MyScheme.gov.in API | Keeps data current without manual updates |
| Voice input (Web Speech API) | Helps rural and low-literacy users |
| PWA / offline mode | Allows use in low-connectivity areas |
| More regional languages (Tamil, Telugu, Bengali) | Broader reach |
| Scheme comparison view | Lets users see two schemes side by side |
| Document upload helper | Guides users through scanning and uploading required documents |
| WhatsApp / SMS integration | Reaches users without smartphones |
| Admin panel for scheme data updates | Non-technical staff can update the JSON without touching code |
| Accessibility audit (WCAG 2.1 AA) | Required for a public-sector deployment |
| State-level scheme data | Currently only central schemes; state schemes would double coverage |
